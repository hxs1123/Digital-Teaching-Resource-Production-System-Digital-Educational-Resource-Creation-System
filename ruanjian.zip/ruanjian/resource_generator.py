import os
import json
import datetime
from typing import Dict, List, Any
from deepseek_client import DeepSeekClient, DoubaoClient
from config import Config

class TeachingResourceGenerator:
    """教学资源生成器"""
    
    def __init__(self, use_doubao=False):
        # 新增参数use_doubao，决定用哪个API
        self.client = DoubaoClient() if use_doubao else DeepSeekClient()
        self.resources = []
    
    def generate_lesson_plan(self, subject: str, topic: str, grade_level: str) -> Dict:
        """生成教案"""
        content = self.client.generate_teaching_content(
            subject=subject,
            topic=topic,
            grade_level=grade_level,
            content_type="教案"
        )
        
        resource = {
            "id": f"lesson_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "type": "lesson_plan",
            "subject": subject,
            "topic": topic,
            "grade_level": grade_level,
            "content": content,
            "created_at": datetime.datetime.now().isoformat(),
            "tags": [subject, topic, grade_level, "教案"]
        }
        
        self.resources.append(resource)
        return resource
    
    def generate_quiz(self, topic: str, subject: str, difficulty: str = "medium", 
                     question_count: int = 5) -> Dict:
        """生成测验"""
        content = self.client.create_quiz(
            topic=topic,
            subject=subject,
            difficulty=difficulty,
            question_count=question_count
        )
        
        resource = {
            "id": f"quiz_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "type": "quiz",
            "subject": subject,
            "topic": topic,
            "difficulty": difficulty,
            "question_count": question_count,
            "content": content,
            "created_at": datetime.datetime.now().isoformat(),
            "tags": [subject, topic, difficulty, "测验"]
        }
        
        self.resources.append(resource)
        return resource
    
    def generate_activities(self, topic: str, subject: str, 
                          activity_type: str = "interactive") -> Dict:
        """生成学习活动"""
        content = self.client.generate_learning_activities(
            topic=topic,
            subject=subject,
            activity_type=activity_type
        )
        
        resource = {
            "id": f"activity_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "type": "activity",
            "subject": subject,
            "topic": topic,
            "activity_type": activity_type,
            "content": content,
            "created_at": datetime.datetime.now().isoformat(),
            "tags": [subject, topic, activity_type, "活动"]
        }
        
        self.resources.append(resource)
        return resource
    
    def analyze_educational_image(self, image_path: str) -> Dict:
        """分析教育图像"""
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"图像文件不存在: {image_path}")
        
        content = self.client.analyze_image(image_path, analysis_type="educational")
        
        resource = {
            "id": f"image_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "type": "image_analysis",
            "image_path": image_path,
            "content": content,
            "created_at": datetime.datetime.now().isoformat(),
            "tags": ["图像分析", "教育价值"]
        }
        
        self.resources.append(resource)
        return resource
    
    def generate_multimodal_content(self, text_prompt: str, image_path: str = None) -> Dict:
        """生成多模态内容"""
        if image_path and os.path.exists(image_path):
            # 使用多模态模型
            base64_image = self.client._encode_image(image_path)
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": text_prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ]
            response = self.client.vision_completion(messages)
            content = response['choices'][0]['message']['content']
        else:
            # 使用文本模型
            messages = [{"role": "user", "content": text_prompt}]
            response = self.client.chat_completion(messages)
            content = response['choices'][0]['message']['content']
        
        resource = {
            "id": f"multimodal_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "type": "multimodal_content",
            "text_prompt": text_prompt,
            "image_path": image_path,
            "content": content,
            "created_at": datetime.datetime.now().isoformat(),
            "tags": ["多模态", "自定义"]
        }
        
        self.resources.append(resource)
        return resource
    
    def save_resource(self, resource: Dict, filename: str = None) -> str:
        """保存资源到文件"""
        if filename is None:
            filename = f"{resource['id']}.json"
        
        filepath = os.path.join(Config.OUTPUT_DIR, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(resource, f, ensure_ascii=False, indent=2)
        
        return filepath
    
    def save_all_resources(self) -> str:
        """保存所有资源"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"resources_{timestamp}.json"
        filepath = os.path.join(Config.OUTPUT_DIR, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.resources, f, ensure_ascii=False, indent=2)
        
        return filepath
    
    def load_resources(self, filepath: str) -> List[Dict]:
        """加载资源文件"""
        with open(filepath, 'r', encoding='utf-8') as f:
            resources = json.load(f)
        
        self.resources.extend(resources)
        return resources
    
    def search_resources(self, query: str, tags: List[str] = None) -> List[Dict]:
        """搜索资源"""
        results = []
        
        for resource in self.resources:
            # 按标签搜索
            if tags:
                if not any(tag in resource.get('tags', []) for tag in tags):
                    continue
            
            # 按内容搜索
            if query.lower() in resource.get('content', '').lower():
                results.append(resource)
            elif query.lower() in resource.get('topic', '').lower():
                results.append(resource)
            elif query.lower() in resource.get('subject', '').lower():
                results.append(resource)
        
        return results
    
    def get_resource_statistics(self) -> Dict:
        """获取资源统计信息"""
        stats = {
            "total_resources": len(self.resources),
            "by_type": {},
            "by_subject": {},
            "by_grade": {},
            "recent_resources": []
        }
        
        for resource in self.resources:
            # 按类型统计
            resource_type = resource.get('type', 'unknown')
            stats['by_type'][resource_type] = stats['by_type'].get(resource_type, 0) + 1
            
            # 按学科统计
            subject = resource.get('subject', 'unknown')
            stats['by_subject'][subject] = stats['by_subject'].get(subject, 0) + 1
            
            # 按年级统计
            grade = resource.get('grade_level', 'unknown')
            stats['by_grade'][grade] = stats['by_grade'].get(grade, 0) + 1
        
        # 最近资源
        sorted_resources = sorted(self.resources, 
                                key=lambda x: x.get('created_at', ''), 
                                reverse=True)
        stats['recent_resources'] = sorted_resources[:5]
        
        return stats 
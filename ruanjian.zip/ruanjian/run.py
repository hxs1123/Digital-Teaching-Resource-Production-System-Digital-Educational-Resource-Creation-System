#!/usr/bin/env python3
"""
数字化教学资源制作系统启动脚本
"""

import os
import sys
import subprocess
import argparse
from pathlib import Path
import urllib.request

def check_python_version():
    """检查Python版本"""
    if sys.version_info < (3, 8):
        print("❌ 错误: 需要Python 3.8或更高版本")
        print(f"当前版本: {sys.version}")
        return False
    return True

# def check_dependencies():
#     """检查依赖包"""
#     required_packages = [
#         'streamlit',
#         'requests',
#         'pillow',
#         'python-dotenv'
#     ]
#     
#     missing_packages = []
#     for package in required_packages:
#         try:
#             __import__(package.replace('-', '_'))
#         except ImportError:
#             missing_packages.append(package)
#     
#     if missing_packages:
#         print(f"❌ 缺少依赖包: {', '.join(missing_packages)}")
#         print("请运行: pip install -r requirements.txt")
#         return False
#     
#     return True

def check_env_file():
    """检查环境配置文件（已废弃，提示用户在config.py中设置API密钥）"""
    print("⚠️  提示: 现在请直接在config.py中设置DEEPSEEK_API_KEY，无需.env文件！")
    return True

# def install_dependencies():
#     """安装依赖包"""
#     print("📦 正在安装依赖包...")
#     try:
#         subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])
#         print("✅ 依赖包安装完成")
#         return True
#     except subprocess.CalledProcessError as e:
#         print(f"❌ 依赖包安装失败: {e}")
#         return False

def run_tests():
    """运行测试"""
    print("🧪 正在运行测试...")
    try:
        result = subprocess.run([sys.executable, 'test_app.py'], capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ 所有测试通过")
            return True
        else:
            print("❌ 部分测试失败")
            print(result.stdout)
            print(result.stderr)
            return False
    except Exception as e:
        print(f"❌ 测试运行失败: {e}")
        return False

def start_app(port=8501, host='localhost'):
    """启动应用"""
    print(f"🚀 正在启动应用...")
    print(f"访问地址: http://{host}:{port}")
    
    try:
        subprocess.run([
            sys.executable, '-m', 'streamlit', 'run', 'app.py',
            '--server.port', str(port),
            '--server.address', host
        ])
    except KeyboardInterrupt:
        print("\n👋 应用已停止")
    except Exception as e:
        print(f"❌ 应用启动失败: {e}")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='YouYuBao教学资源制作系统')
    # parser.add_argument('--install', action='store_true', help='安装依赖包')
    parser.add_argument('--test', action='store_true', help='运行测试')
    parser.add_argument('--port', type=int, default=8501, help='端口号 (默认: 8501)')
    parser.add_argument('--host', default='localhost', help='主机地址 (默认: localhost)')
    parser.add_argument('--skip-checks', action='store_true', help='跳过检查直接启动')
    
    args = parser.parse_args()
    
    print("🎓 YouYuBao教学资源制作系统")
    print("=" * 50)
    
    # # 安装依赖
    # if args.install:
    #     if not install_dependencies():
    #         return 1
    
    # 跳过检查
    if args.skip_checks:
        start_app(args.port, args.host)
        return 0
    
    # 检查Python版本
    if not check_python_version():
        return 1
    
    # # 检查依赖
    # if not check_dependencies():
    #     print("\n💡 提示: 运行 --install 参数自动安装依赖")
    #     return 1
    
    # 检查环境配置
    if not check_env_file():
        print("\n💡 提示: 请配置.env文件后重新运行")
        return 1
    
    # 运行测试
    if args.test:
        if not run_tests():
            return 1
    
    # 启动应用
    start_app(args.port, args.host)
    return 0

if __name__ == '__main__':
    exit(main())

url = "https://github.com/owent-utils/font/raw/master/simhei.ttf"
urllib.request.urlretrieve(url, "simhei.ttf")
print("simhei.ttf 下载完成") 
import streamlit as st
import os
import json
import plotly.express as px
from datetime import datetime
from config import Config
from resource_generator import TeachingResourceGenerator
import re
from docx import Document
from fpdf import FPDF
from resource_db import ResourceDB
from PIL import Image
import time
import streamlit.components.v1 as components
import base64
import sys
import streamlit_cookies_manager
import bcrypt
import html
import uuid

# 兼容PyInstaller打包和源码运行的资源路径查找

def get_resource_path(filename):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, filename)
    return os.path.join(os.path.dirname(__file__), filename)

# 登录相关工具函数

def login_popup():
    st.session_state['show_login'] = True

def logout():
    st.session_state['logged_in'] = False
    st.session_state['username'] = ''
    st.session_state['is_admin'] = False
    cookies['logged_in'] = '0'
    cookies['username'] = ''
    cookies['is_admin'] = '0'
    cookies.save()

def do_login(db, username, password, is_admin):
    if is_admin:
        admin = db.get_admin(username)
        if not admin:
            db.add_admin(username, password)
            st.session_state['is_admin'] = True
            st.session_state['logged_in'] = True
            st.session_state['username'] = username
            st.session_state['show_login'] = False
            # 添加登录日志
            log_action(db, username, "管理员首次注册并登录", True)
        else:
            # 验证管理员密码
            _, _, admin_password, _ = admin
            # 兼容bcrypt加密和明文
            try:
                valid = bcrypt.checkpw(password.encode('utf-8'), admin_password.encode('utf-8'))
            except Exception:
                valid = (admin_password == password)
            if valid:
                st.session_state['is_admin'] = True
                st.session_state['logged_in'] = True
                st.session_state['username'] = username
                st.session_state['show_login'] = False
                # 添加登录日志
                log_action(db, username, "管理员登录", True)
            else:
                st.error("管理员密码错误，请重试！")
                return False
    else:
        user = db.get_user(username)
        if not user:
            db.add_user(username, password)
            st.session_state['is_admin'] = False
            st.session_state['logged_in'] = True
            st.session_state['username'] = username
            st.session_state['show_login'] = False
            # 添加登录日志
            log_action(db, username, "用户首次注册并登录", False)
        else:
            # 验证用户密码
            _, _, user_password, _ = user
            # 兼容bcrypt加密和明文
            try:
                valid = bcrypt.checkpw(password.encode('utf-8'), user_password.encode('utf-8'))
            except Exception:
                valid = (user_password == password)
            if valid:
                st.session_state['is_admin'] = False
                st.session_state['logged_in'] = True
                st.session_state['username'] = username
                st.session_state['show_login'] = False
                # 添加登录日志
                log_action(db, username, "用户登录", False)
            else:
                st.error("用户密码错误，请重试！")
                return False
    # 登录成功后写入cookie
    cookies['logged_in'] = '1'
    cookies['username'] = username
    cookies['is_admin'] = '1' if is_admin else '0'
    cookies.save()
    return True

def log_action(db, username, action, is_admin=False):
    """记录用户操作日志"""
    try:
        user_type = "管理员" if is_admin else "普通用户"
        db.add_log(username, action, user_type)
    except:
        # 如果日志表不存在，创建它
        db.create_log_table()
        db.add_log(username, action, user_type)

# 页面配置
st.set_page_config(
    page_title="YouYuBao",
    page_icon="logo.jpg",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 全局CSS美化
st.markdown("""
<style>
body, .main, .block-container {
    font-family: 'SimSun', '宋体', serif !important;
}
.main-header {
    font-size: 3rem;
    color: #1976d2;
    text-align: center;
    margin-bottom: 2.5rem;
    font-weight: bold;
    letter-spacing: 2px;
    font-family: 'SimSun', '宋体', serif !important;
}
.youyubao-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #f5f7fa;
    padding: 1rem 2rem 1rem 2rem;
    border-radius: 1rem;
    margin-bottom: 2rem;
}
.youyubao-logo {
    height: 60px;
    margin-right: 1.2rem;
}
.youyubao-title {
    font-size: 2.5rem;
    color: #1976d2;
    font-weight: bold;
    letter-spacing: 2px;
    font-family: 'SimSun', '宋体', serif !important;
}
.login-btn {
    background: #1976d2;
    color: #fff;
    border: none;
    border-radius: 0.5rem;
    padding: 0.5rem 1.5rem;
    font-size: 1.1rem;
    font-weight: bold;
    cursor: pointer;
    margin-left: 1rem;
    transition: background 0.3s;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}
.login-btn:hover {
    background: #0d47a1;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
}
.feature-card {
    background-color: #f0f2f6;
    padding: 1.2rem;
    border-radius: 0.7rem;
    margin: 0.7rem 0;
    font-size: 1.1rem;
    font-family: 'SimSun', '宋体', serif !important;
}
.success-message {
    background-color: #d4edda;
    color: #155724;
    padding: 1rem;
    border-radius: 0.5rem;
    margin: 1rem 0;
    font-family: 'SimSun', '宋体', serif !important;
}
.error-message {
    background-color: #f8d7da;
    color: #721c24;
    padding: 1rem;
    border-radius: 0.5rem;
    margin: 1rem 0;
    font-family: 'SimSun', '宋体', serif !important;
}
.sidebar-title {
    font-size: 1.3rem;
    color: #1976d2;
    font-weight: bold;
    margin-bottom: 1.2rem;
    text-align: left;
    font-family: 'SimSun', '宋体', serif !important;
}
.sidebar-btn {
    width: 100%;
    margin-bottom: 0.7rem;
    font-size: 1.1rem;
    text-align: left;
    background: #f5f7fa;
    color: #1976d2;
    border-radius: 0.5rem;
    border: none;
    padding: 0.7rem 1rem;
    transition: background 0.2s;
    font-family: 'SimSun', '宋体', serif !important;
}
.sidebar-btn:hover {
    background: #e3eafc;
    color: #0d47a1;
    font-family: 'SimSun', '宋体', serif !important;
}
.metric-label {
    font-size: 1.1rem !important;
    color: #1976d2 !important;
    font-weight: bold !important;
    font-family: 'SimSun', '宋体', serif !important;
}
.metric-value {
    font-size: 2.2rem !important;
    color: #333 !important;
    font-weight: bold !important;
    font-family: 'SimSun', '宋体', serif !important;
}
.login-overlay {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(25, 118, 210, 0.85);
    padding: 20px;
    color: white;
    text-align: center;
    border-top: 3px solid #0d47a1;
    box-shadow: 0 -5px 15px rgba(0,0,0,0.2);
    z-index: 1000;
    backdrop-filter: blur(3px);
    -webkit-backdrop-filter: blur(3px);
    animation: slideUp 0.8s ease-out;
}
.login-overlay-content {
    max-width: 800px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.login-overlay-text {
    font-size: 1.2rem;
    font-weight: bold;
    margin-right: 20px;
}
.login-overlay-btn {
    background: white;
    color: #1976d2;
    border: none;
    padding: 8px 25px;
    border-radius: 30px;
    font-weight: bold;
    font-size: 1.1rem;
    cursor: pointer;
    transition: all 0.3s;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}
.login-overlay-btn:hover {
    background: #f0f2f6;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
}
.pulse-animation {
    animation: pulse 2s infinite;
}
@keyframes pulse {
    0% {
        box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7);
    }
    70% {
        box-shadow: 0 0 0 10px rgba(255, 255, 255, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(255, 255, 255, 0);
    }
}
/* 页面淡入效果 */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
@keyframes slideUp {
    from {
        transform: translateY(100%);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}
.fade-in {
    animation: fadeIn 0.8s ease-out;
}
.fade-in-slow {
    animation: fadeIn 1.2s ease-out;
}
.fade-in-delay {
    animation: fadeIn 1.5s ease-out 0.3s both;
}
.feature-card {
    animation: fadeIn 0.8s ease-out;
    transition: transform 0.3s, box-shadow 0.3s;
}
.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 15px rgba(0,0,0,0.1);
}

/* 登录后页面的所有可点击项悬停高亮效果 */
/* 按钮通用悬停效果 */
button, .stButton>button {
    transition: all 0.3s ease !important;
}
button:hover, .stButton>button:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15) !important;
    filter: brightness(1.05) !important;
}

/* 表单提交按钮 */
.stFormSubmit>button {
    transition: all 0.3s ease !important;
}
.stFormSubmit>button:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 4px 8px rgba(25, 118, 210, 0.3) !important;
    filter: brightness(1.05) !important;
}

/* 卡片和可展开项 */
.stExpander, div[data-testid="stExpander"] {
    transition: all 0.3s ease !important;
    border-radius: 8px !important;
}
.stExpander:hover, div[data-testid="stExpander"]:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
    border-color: #1976d2 !important;
}

/* 链接 */
a {
    transition: all 0.3s ease !important;
    text-decoration: none !important;
}
a:hover {
    color: #0d47a1 !important;
    text-decoration: underline !important;
}

/* 选择框和输入框 */
.stSelectbox, .stTextInput, .stTextArea, .stDateInput, .stTimeInput, .stNumberInput {
    transition: all 0.3s ease !important;
}
.stSelectbox:hover, .stTextInput:hover, .stTextArea:hover, .stDateInput:hover, .stTimeInput:hover, .stNumberInput:hover {
    border-color: #1976d2 !important;
    box-shadow: 0 0 0 1px rgba(25, 118, 210, 0.3) !important;
}

/* 文件上传区域 */
.stFileUploader {
    transition: all 0.3s ease !important;
    border-radius: 8px !important;
}
.stFileUploader:hover {
    border-color: #1976d2 !important;
    box-shadow: 0 0 10px rgba(25, 118, 210, 0.2) !important;
}

/* 统计卡片 */
div[data-testid="stMetric"] {
    transition: all 0.3s ease !important;
    border-radius: 8px !important;
    padding: 10px !important;
}
div[data-testid="stMetric"]:hover {
    background-color: #f5f7fa !important;
    transform: translateY(-3px) !important;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
}

/* 资源项和列表项 */
.resource-item, .list-item {
    transition: all 0.3s ease !important;
    border-radius: 8px !important;
    padding: 10px !important;
}
.resource-item:hover, .list-item:hover {
    background-color: #f5f7fa !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1) !important;
}
</style>
""", unsafe_allow_html=True)

# 侧边栏全部展开的功能导航
sidebar_pages = [
    ("🏠 首页", "show_home_page"),
    ("📝 教案生成", "show_lesson_plan_page"),
    ("❓ 测验生成", "show_quiz_page"),
    ("🎯 活动设计", "show_activity_page"),
    ("🖼️ 图像分析", "show_image_analysis_page"),
    ("🔍 多模态内容", "show_multimodal_page"),
    ("📊 资源管理", "show_resource_management_page"),
    ("👤 个人中心", "show_profile_page"),
    ("⚙️ 系统设置", "show_settings_page")
]

# 确保sidebar_page已初始化，防止刷新后丢失
if 'sidebar_page' not in st.session_state:
    st.session_state['sidebar_page'] = '🏠 首页'

# 仅登录后才显示侧边栏
if st.session_state.get('logged_in', False):
    if 'sidebar_page' not in st.session_state:
        st.session_state.sidebar_page = sidebar_pages[0][0]
    with st.sidebar:
        st.markdown("<div class='sidebar-title'>选择功能模块</div>", unsafe_allow_html=True)
        for name, func in sidebar_pages:
            if st.button(name, key=f"sidebar_{name}", use_container_width=True):
                st.session_state.sidebar_page = name

# 初始化会话状态
if 'generator' not in st.session_state:
    st.session_state.generator = TeachingResourceGenerator(use_doubao=True)

if 'current_resource' not in st.session_state:
    st.session_state.current_resource = None

# 初始化数据库
if 'db' not in st.session_state:
    st.session_state.db = ResourceDB()

# 初始化cookie管理器
cookies = streamlit_cookies_manager.EncryptedCookieManager(prefix="yyb_", password="yyb_cookie_secret_2024")
cookies_ready = cookies.ready()

# 登录状态初始化，优先从cookie读取
if 'logged_in' not in st.session_state:
    st.session_state['logged_in'] = cookies.get('logged_in') == '1'
    st.session_state['username'] = cookies.get('username') or ''
    st.session_state['is_admin'] = cookies.get('is_admin') == '1'
if 'show_login' not in st.session_state:
    st.session_state['show_login'] = False

# 顶部logo+标题+登录按钮
with st.container():
    cols = st.columns([1.3,1.7,1])
    with cols[2]:
        if st.session_state['logged_in']:
            st.markdown(f"<span style='font-size:1.1rem;color:#1976d2;'>欢迎，{st.session_state['username']} {'(管理员)' if st.session_state['is_admin'] else ''}</span>", unsafe_allow_html=True)
            if st.button('退出登录', key='logout_btn', use_container_width=True):
                logout()
                st.rerun()
        else:
            if st.button('登录', key='login_btn', use_container_width=True, type="primary"):
                login_popup()

# 登录弹窗
if st.session_state['show_login']:
    with st.form('login_form', clear_on_submit=True):
        st.markdown('#### 登录YuYou')
        username = st.text_input('用户名')
        password = st.text_input('密码', type='password')
        is_admin = st.checkbox('管理员登录')
        submitted = st.form_submit_button('登录')
        if submitted:
            if username and password:
                login_success = do_login(st.session_state.db, username, password, is_admin)
                if login_success:
                    st.success('登录成功！')
                    st.rerun()
            else:
                st.error('请输入用户名和密码')
        if st.form_submit_button('取消'):
            st.session_state['show_login'] = False
            st.rerun()

# 未登录时只显示丰富美观的欢迎页
if not st.session_state['logged_in']:
    # 用base64编码logo图片并用HTML居中显示，彻底解决居中问题
    try:
        with open(get_resource_path('logo.jpg'), 'rb') as f:
            logo_data = f.read()
    except Exception:
        # 兼容老路径，找不到时尝试原始方式
        with open('logo.jpg', 'rb') as f:
            logo_data = f.read()
    logo_base64 = base64.b64encode(logo_data).decode()
    st.markdown(f'''<div style="width:100%;display:flex;justify-content:center;align-items:center;margin-top:3vh;margin-bottom:0.5vh;">
        <img src="data:image/jpeg;base64,{logo_base64}" style="width:600px;max-width:95vw;display:block;"/>
    </div>''', unsafe_allow_html=True)
    st.markdown('<div style="font-size:3.6rem;color:#1976d2;font-weight:bold;letter-spacing:10px;text-align:center;margin-top:18px;" class="fade-in">YouYuBao</div>', unsafe_allow_html=True)
    st.markdown('''
    <div class="main-content-fadein" style="margin-top:2vh;">
        <h1 style="text-align:center;font-size:2.8rem;color:#1976d2;font-weight:bold;letter-spacing:2px;" class="fade-in">欢迎使用 <span style='color:#1565c0;'>YouYuBao</span> 教学资源制作系统</h1>
        <p style="text-align:center;font-size:1.3rem;color:#444;margin:18px 0 30px 0;" class="fade-in-slow">基于多模态大模型的AI驱动数字化教学资源平台</p>
        <div style="display:flex;justify-content:center;gap:40px;margin-bottom:30px;flex-wrap:wrap;" class="fade-in-delay">
            <div style="background:#e3eafc;border-radius:1rem;padding:1.2rem 2.2rem;min-width:220px;margin:10px;box-shadow:0 2px 8px #e3eafc;" class="feature-card">
                <span style="font-size:2.2rem;">🤖</span><br/>
                <span style="font-size:1.1rem;color:#1976d2;font-weight:bold;">多模态大模型</span><br/>
                <span style="color:#666;">文本+图像+智能分析</span>
            </div>
            <div style="background:#f0f2f6;border-radius:1rem;padding:1.2rem 2.2rem;min-width:220px;margin:10px;box-shadow:0 2px 8px #f0f2f6;" class="feature-card">
                <span style="font-size:2.2rem;">🚀</span><br/>
                <span style="font-size:1.1rem;color:#1976d2;font-weight:bold;">AI驱动</span><br/>
                <span style="color:#666;">自动生成教案/测验/活动</span>
            </div>
            <div style="background:#e3eafc;border-radius:1rem;padding:1.2rem 2.2rem;min-width:220px;margin:10px;box-shadow:0 2px 8px #e3eafc;" class="feature-card">
                <span style="font-size:2.2rem;">📊</span><br/>
                <span style="font-size:1.1rem;color:#1976d2;font-weight:bold;">数字化教学</span><br/>
                <span style="color:#666;">资源管理与可视化</span>
            </div>
        </div>
        <div style="margin-top:30px;font-size:1.1rem;color:#888;text-align:center;" class="fade-in-delay">
            <b>平台特色：</b> 支持多学科、智能生成、资源导出、可视化统计、用户分级管理等<br/>
            <b>技术亮点：</b> 先进AI算法、中文优化、极简操作、现代美观UI
        </div>
        <div style="margin-top:40px;color:#aaa;font-size:1rem;text-align:center;" class="fade-in-delay">请先登录后使用全部功能</div>
    </div>
    
    <div class="login-overlay">
        <div class="login-overlay-content">
            <div class="login-overlay-text">🔐 登录后即可体验全部功能，开启AI驱动的教学资源制作之旅</div>
            <button class="login-overlay-btn pulse-animation" onclick="document.querySelector('[data-testid=stFormSubmitButton]').click()">立即登录</button>
        </div>
    </div>
    ''', unsafe_allow_html=True)
    st.stop()

# 工具函数：格式化内容为纯文本
def format_content_for_plaintext(content):
    # 先将\\n替换为换行，\\t为制表符，去除多余转义
    text = content.replace('\\n', '\n').replace('\\t', '\t').replace('\\r', '')
    # 去掉多余的反斜杠（只保留真正的转义）
    text = re.sub(r'\\+', '', text)
    return text

def filter_sensitive(text):
    # 简单敏感词过滤和脱敏，可扩展
    sensitive_words = ['密码', 'password', 'api_key', 'apikey', 'token', '密钥']
    for w in sensitive_words:
        text = text.replace(w, '[敏感信息]')
    return text

def save_content_as_word(content, filename, title=None):
    from docx.shared import Pt
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    from typing import cast, Any
    doc = Document()
    style = doc.styles['Normal']
    style_font = cast(Any, style).font
    style_font.name = "宋体"
    style_font.size = Pt(12)
    style_font.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    # 设置正文段落行距、段前段后
    style_paragraph = doc.styles['Normal'].paragraph_format
    style_paragraph.line_spacing = 1.5
    style_paragraph.space_before = Pt(6)
    style_paragraph.space_after = Pt(6)
    if title:
        heading = doc.add_heading(html.escape(filter_sensitive(title)), level=1)
        for run in heading.runs:
            run.font.name = "宋体"
            run.font.size = Pt(18)
            run.bold = True
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        heading.alignment = 1  # 居中
    for line in content.split('\n'):
        line = line.strip()
        # 对内容进行HTML转义和敏感词过滤
        line = html.escape(filter_sensitive(line))
        # 去除常见花体星号符号
        line = re.sub(r'[❉✳✻✽❈❊❋❃❂❀＊*]+', '', line)
        # （已撤销）不再去除行首特殊符号
        if not line:
            p = doc.add_paragraph('')
            for run in p.runs:
                run.font.name = "宋体"
                run.font.size = Pt(12)
                run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        elif line.startswith('###'):
            heading = doc.add_heading(line.replace('#', '').strip(), level=2)
            for run in heading.runs:
                run.font.name = "宋体"
                run.font.size = Pt(16)
                run.bold = True
                run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
            heading.alignment = 0
        elif line.startswith('**') and line.endswith('**'):
            p = doc.add_paragraph()
            run = p.add_run(line.replace('**', ''))
            run.bold = True
            run.font.name = "宋体"
            run.font.size = Pt(14)
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        elif line.startswith('- '):
            para = doc.add_paragraph(line[2:], style='List Bullet')
            for run in para.runs:
                run.font.name = "宋体"
                run.font.size = Pt(12)
                run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        elif line[0:2].isdigit() and line[2] == '.':
            para = doc.add_paragraph(line, style='List Number')
            for run in para.runs:
                run.font.name = "宋体"
                run.font.size = Pt(12)
                run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        else:
            para = doc.add_paragraph(line)
            for run in para.runs:
                run.font.name = "宋体"
                run.font.size = Pt(12)
                run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    # 文件名自动重命名为UUID，防止路径遍历和覆盖
    ext = filename.split('.')[-1]
    import os
    from config import Config
    filename = os.path.join(Config.OUTPUT_DIR, f"{uuid.uuid4()}.{ext}")
    doc.save(filename)
    return filename

def save_content_as_pdf(content, filename, title=None):
    from fpdf import FPDF
    import uuid
    import os
    from config import Config
    ext = filename.split('.')[-1]
    filename = os.path.join(Config.OUTPUT_DIR, f"{uuid.uuid4()}.{ext}")
    pdf = FPDF()
    pdf.add_page()
    font_path = "Fonts/simsunb.ttf"
    # 每次都注册字体，避免Undefined font
    pdf.add_font('SimSunB', '', font_path, uni=True)
    pdf.set_font("SimSunB", size=14)
    if title:
        pdf.set_font("SimSunB", 'B', 16)
        pdf.cell(0, 12, title, ln=1, align='C')
        pdf.set_font("SimSunB", size=12)
        pdf.ln(4)
    for line in content.split('\n'):
        line = line.strip()
        if not line:
            pdf.ln(6)
        elif line.startswith('###'):
            pdf.set_font("SimSunB", 'B', 13)
            pdf.cell(0, 10, line.replace('#', '').strip(), ln=1)
            pdf.set_font("SimSunB", size=12)
        elif line.startswith('**') and line.endswith('**'):
            pdf.set_font("SimSunB", 'B', 12)
            pdf.cell(0, 8, line.replace('**', ''), ln=1)
            pdf.set_font("SimSunB", size=12)
        elif line.startswith('- '):
            pdf.cell(0, 8, u'• ' + line[2:], ln=1)
        elif line[0:2].isdigit() and line[2] == '.':
            pdf.cell(0, 8, line, ln=1)
        else:
            pdf.cell(0, 8, line, ln=1)
    pdf.output(filename)
    return filename

def save_resource_to_db(resource):
    resource['username'] = st.session_state['username']  # 添加用户名到资源
    st.session_state.db.save_resource(resource)
    
    # 记录创建资源的日志
    log_action(st.session_state.db, st.session_state['username'], 
               f"创建{resource['type']}资源: {resource.get('topic', '未命名')}", 
               st.session_state['is_admin'])

def render_content_with_math(content):
    """自动检测内容中的LaTeX公式并分行渲染，普通文本用markdown，公式用latex。防止XSS攻击。"""
    lines = content.split('\n')
    for line in lines:
        line = line.strip()
        # 对所有用户内容进行HTML转义，防止XSS
        line = html.escape(line)
        if not line:
            st.markdown("\n")
        # 优化：自动将\\( ... \\)、\\[ ... \\]、$$...$$等全部转为$...$包裹
        elif re.search(r'(\\\(.*?\\\))|(\\\[.*?\\\])|(\$\$.*?\$\$)', line):
            # 统一替换为$...$
            line = re.sub(r'\\\((.*?)\\\)', r'$\1$', line)
            line = re.sub(r'\\\[(.*?)\\\]', r'$\1$', line)
            line = re.sub(r'\$\$(.*?)\$\$', r'$\1$', line)
            st.latex(line)
        # 兼容$...$公式
        elif re.search(r'\$.*?\$', line):
            st.latex(line)
        else:
            st.markdown(line, unsafe_allow_html=True)

# 专门用于渲染数学公式的函数
def render_math_content(content):
    """与render_content_with_math保持兼容的函数"""
    render_content_with_math(content)

def main():
    """主函数"""
    # 标题
    st.markdown('<h1 class="main-header">🎓 YouYuBao教学资源制作系统</h1>', unsafe_allow_html=True)
    
    # 页面路由
    page = st.session_state.sidebar_page
    if page == "🏠 首页":
        show_home_page()
    elif page == "📝 教案生成":
        show_lesson_plan_page()
    elif page == "❓ 测验生成":
        show_quiz_page()
    elif page == "🎯 活动设计":
        show_activity_page()
    elif page == "🖼️ 图像分析":
        show_image_analysis_page()
    elif page == "🔍 多模态内容":
        show_multimodal_page()
    elif page == "📊 资源管理":
        show_resource_management_page()
    elif page == "👤 个人中心":
        show_profile_page()
    elif page == "⚙️ 系统设置":
        show_settings_page()

def show_home_page():
    """首页"""
    st.markdown("## 🎯 系统概述")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### ✨ 主要功能
        - **智能教案生成**: 基于AI的个性化教案制作
        - **测验题目创建**: 自动生成多种题型的测验
        - **学习活动设计**: 互动式教学活动规划
        - **图像内容分析**: 教育图像智能分析
        - **多模态内容**: 文本+图像的综合处理
        - **资源管理系统**: 完整的教学资源库
        """)
    
    with col2:
        st.markdown("""
        ### 🚀 技术特色
        - **DeepSeek多模态AI**: 先进的AI技术支撑
        - **中文优化**: 专门针对中文教育场景
        - **用户友好**: 直观的图形界面
        - **资源丰富**: 支持多种教学资源类型
        - **智能推荐**: 基于内容的智能匹配
        """)
    
    # 统计信息
    col_title, col_refresh = st.columns([6, 1])
    with col_title:
        st.markdown("## 📊 系统统计")
    with col_refresh:
        refresh_clicked = st.button("🔄 刷新", key="refresh_stats_btn", help="刷新统计数据")
    
    # 添加分隔线
    st.markdown("<hr style='margin: 0.5rem 0; opacity: 0.3;'>", unsafe_allow_html=True)
    
    # 统计从数据库读取
    db_resources = st.session_state.db.get_all_resources()
    stats = {
        'total_resources': len(db_resources),
        'by_type': {},
        'recent_resources': db_resources[:5]
    }
    for r in db_resources:
        t = r.get('type', 'unknown')
        stats['by_type'][t] = stats['by_type'].get(t, 0) + 1
    
    # 使用简单的列布局显示统计数据
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("总资源数", stats['total_resources'])
    with col2:
        st.metric("教案数量", stats['by_type'].get('lesson_plan', 0))
    with col3:
        st.metric("测验数量", stats['by_type'].get('quiz', 0))
    with col4:
        st.metric("活动数量", stats['by_type'].get('activity', 0))
    
    # 如果点击了刷新按钮，重新加载页面
    if refresh_clicked:
        st.rerun()
    
    # 最近资源
    if stats['recent_resources']:
        st.markdown("## 📝 最近创建的资源")
        for i, resource in enumerate(stats['recent_resources']):
            with st.expander(f"{resource['type']} - {resource.get('topic', '未知主题')}"):
                render_content_with_math(resource['content'])
                # 只有资源所有者或管理员可以删除
                if resource.get('username') == st.session_state['username'] or st.session_state['is_admin']:
                    if st.button("🗑️ 删除此资源", key=f"del_home_{i}_{resource['id']}"):
                        st.session_state.db.delete_resource(resource['id'])
                        log_action(st.session_state.db, st.session_state['username'], 
                                  f"从首页删除资源: {resource.get('topic', '未命名')}", 
                                  st.session_state['is_admin'])
                        st.success("资源已删除")
                        st.rerun()

def show_lesson_plan_page():
    """教案生成页面"""
    st.markdown("## 📝 智能教案生成")
    
    with st.form("lesson_plan_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            subject = st.selectbox(
                "选择学科",
                ["语文", "数学", "英语", "物理", "化学", "生物", "历史", "地理", "政治", "其他"]
            )
            
            grade_level = st.selectbox(
                "选择年级",
                ["小学一年级", "小学二年级", "小学三年级", "小学四年级", "小学五年级", "小学六年级",
                 "初中一年级", "初中二年级", "初中三年级",
                 "高中一年级", "高中二年级", "高中三年级"]
            )
        
        with col2:
            topic = st.text_input("教学主题", placeholder="例如：二次函数、古诗文鉴赏...")
            
            content_type = st.selectbox(
                "内容类型",
                ["教案", "教学大纲", "课程设计", "教学反思"]
            )
        
        submitted = st.form_submit_button("🚀 生成教案")
        
        if submitted and topic:
            with st.spinner("正在生成教案，请稍候..."):
                try:
                    resource = st.session_state.generator.generate_lesson_plan(
                        subject=subject,
                        topic=topic,
                        grade_level=grade_level
                    )
                    
                    st.session_state.current_resource = resource
                    st.success("教案生成成功！")
                    
                except Exception as e:
                    st.error(f"生成失败: {str(e)}")
    
    # 显示生成的资源
    if st.session_state.current_resource:
        display_resource(st.session_state.current_resource)

def show_quiz_page():
    """测验生成页面"""
    st.markdown("## ❓ 智能测验生成")
    
    with st.form("quiz_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            subject = st.selectbox(
                "选择学科",
                ["语文", "数学", "英语", "物理", "化学", "生物", "历史", "地理", "政治", "其他"]
            )
            
            difficulty = st.selectbox(
                "难度等级",
                ["easy", "medium", "hard"]
            )
        
        with col2:
            topic = st.text_input("测验主题", placeholder="例如：三角函数、英语语法...")
            
            question_count = st.slider("题目数量", 3, 20, 5)
        
        submitted = st.form_submit_button("🎯 生成测验")
        
        if submitted and topic:
            with st.spinner("正在生成测验，请稍候..."):
                try:
                    resource = st.session_state.generator.generate_quiz(
                        topic=topic,
                        subject=subject,
                        difficulty=difficulty,
                        question_count=question_count
                    )
                    
                    st.session_state.current_resource = resource
                    st.success("测验生成成功！")
                    
                except Exception as e:
                    st.error(f"生成失败: {str(e)}")
    
    # 显示生成的资源
    if st.session_state.current_resource:
        display_resource(st.session_state.current_resource)

def show_activity_page():
    """活动设计页面"""
    st.markdown("## 🎯 学习活动设计")
    
    with st.form("activity_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            subject = st.selectbox(
                "选择学科",
                ["语文", "数学", "英语", "物理", "化学", "生物", "历史", "地理", "政治", "其他"]
            )
            
            activity_type = st.selectbox(
                "活动类型",
                ["interactive", "group", "individual", "experiment", "discussion", "presentation"]
            )
        
        with col2:
            topic = st.text_input("活动主题", placeholder="例如：科学实验、小组讨论...")
        
        submitted = st.form_submit_button("🎨 设计活动")
        
        if submitted and topic:
            with st.spinner("正在设计活动，请稍候..."):
                try:
                    resource = st.session_state.generator.generate_activities(
                        topic=topic,
                        subject=subject,
                        activity_type=activity_type
                    )
                    
                    st.session_state.current_resource = resource
                    st.success("活动设计成功！")
                    
                except Exception as e:
                    st.error(f"设计失败: {str(e)}")
    
    # 显示生成的资源
    if st.session_state.current_resource:
        display_resource(st.session_state.current_resource)

def show_image_analysis_page():
    """图像分析页面"""
    st.markdown("## 🖼️ 教育图像分析")

    uploaded_file = st.file_uploader(
        "上传图像文件",
        type=['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'],
        help="支持JPG、PNG、GIF、BMP、WebP格式"
    )

    if uploaded_file is not None:
        # 保存上传的文件
        file_path = os.path.join(Config.TEMP_DIR, uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        # 检查图片大小
        if os.path.getsize(file_path) > 1024 * 1024:
            st.error("图片过大，请上传小于1MB的图片！")
            return

        # 显示图像
        st.image(uploaded_file, caption="上传的图像", use_column_width=True)

        if st.button("🔍 分析图像"):
            with st.spinner("正在分析图像，请稍候..."):
                try:
                    resource = st.session_state.generator.analyze_educational_image(file_path)
                    st.session_state.current_resource = resource
                    st.success("图像分析完成！")
                except Exception as e:
                    st.error(f"分析失败: {str(e)}")

    # 显示分析结果
    if st.session_state.current_resource:
        display_resource(st.session_state.current_resource)

def show_multimodal_page():
    """多模态内容页面"""
    st.markdown("## 🔍 多模态内容生成")

    with st.form("multimodal_form"):
        text_prompt = st.text_area(
            "输入文本提示",
            placeholder="请描述您想要生成的内容...",
            height=100
        )

        uploaded_file = st.file_uploader(
            "上传图像（可选）",
            type=['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp']
        )

        submitted = st.form_submit_button("🚀 生成内容")

        if submitted and text_prompt:
            image_path = None
            if uploaded_file is not None:
                # 保存上传的文件
                image_path = os.path.join(Config.TEMP_DIR, uploaded_file.name)
                with open(image_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                # 检查图片大小
                if os.path.getsize(image_path) > 1024 * 1024:
                    st.error("图片过大，请上传小于1MB的图片！")
                    return
                st.image(uploaded_file, caption="上传的图像", use_column_width=True)

            with st.spinner("正在生成内容，请稍候..."):
                try:
                    resource = st.session_state.generator.generate_multimodal_content(
                        text_prompt=text_prompt,
                        image_path=image_path
                    )
                    st.session_state.current_resource = resource
                    st.success("内容生成成功！")
                except Exception as e:
                    st.error(f"生成失败: {str(e)}")

    # 显示生成的资源
    if st.session_state.current_resource:
        display_resource(st.session_state.current_resource)

def show_resource_management_page():
    """资源管理页面"""
    st.markdown("## 📊 资源管理")
    
    # 添加个人资源和全部资源的选项卡
    tab1, tab2 = st.tabs(["我的资源", "全部资源"])
    
    with tab1:
        # 我的资源搜索功能
        col1, col2 = st.columns([2, 1])
        
        with col1:
            search_query = st.text_input("搜索我的资源", placeholder="输入关键词搜索...", key="my_search")
        
        with col2:
            search_tags = st.multiselect(
                "按标签筛选",
                ["教案", "测验", "活动", "图像分析", "多模态"],
                key="my_tags"
            )
        
        if st.button("🔍 搜索我的资源", key="search_my"):
            # 添加用户名过滤条件
            results = st.session_state.db.search_user_resources(
                st.session_state['username'], 
                search_query, 
                search_tags
            )
            
            if results:
                st.markdown(f"### 找到 {len(results)} 个资源")
                for i, resource in enumerate(results):
                    with st.expander(f"{resource['type']} - {resource.get('topic', '未知主题')}"):
                        render_content_with_math(resource['content'])
                        # 添加删除按钮，使用索引和ID组合作为唯一键
                        if st.button("🗑️ 删除此资源", key=f"del_my_{i}_{resource['id']}"):
                            st.session_state.db.delete_resource(resource['id'])
                            log_action(st.session_state.db, st.session_state['username'], 
                                       f"删除资源: {resource.get('topic', '未命名')}", 
                                       st.session_state['is_admin'])
                            st.success("资源已删除")
                            st.rerun()
            else:
                st.info("未找到匹配的资源")
    
    with tab2:
        # 全部资源搜索功能 - 与原来的代码相同
        col1, col2 = st.columns([2, 1])
        
        with col1:
            search_query = st.text_input("搜索全部资源", placeholder="输入关键词搜索...")
        
        with col2:
            search_tags = st.multiselect(
                "按标签筛选",
                ["教案", "测验", "活动", "图像分析", "多模态"]
            )
        
        if st.button("🔍 搜索"):
            results = st.session_state.db.search_resources(search_query, search_tags)
            
            if results:
                st.markdown(f"### 找到 {len(results)} 个资源")
                for i, resource in enumerate(results):
                    with st.expander(f"{resource['type']} - {resource.get('topic', '未知主题')}"):
                        st.write(f"创建者: {resource.get('username', '未知用户')}")
                        render_content_with_math(resource['content'])
                        # 管理员可以删除任何资源，使用索引和ID组合作为唯一键
                        if st.session_state['is_admin']:
                            if st.button("🗑️ 删除此资源", key=f"del_admin_{i}_{resource['id']}"):
                                st.session_state.db.delete_resource(resource['id'])
                                log_action(st.session_state.db, st.session_state['username'], 
                                           f"管理员删除资源: {resource.get('topic', '未命名')}", 
                                           True)
                                st.success("资源已删除")
                                st.rerun()
            else:
                st.info("未找到匹配的资源")
    
    # 统计图表
    st.markdown("### 📈 资源统计")
    db_resources = st.session_state.db.get_all_resources()
    stats = {'by_type': {}, 'by_subject': {}}
    for r in db_resources:
        t = r.get('type', 'unknown')
        stats['by_type'][t] = stats['by_type'].get(t, 0) + 1
        s = r.get('subject', 'unknown')
        stats['by_subject'][s] = stats['by_subject'].get(s, 0) + 1
    col1, col2 = st.columns(2)
    
    with col1:
        if stats['by_type']:
            # 使用索引方式创建DataFrame，避免类型错误
            type_data = list(stats['by_type'].items())
            df_type = [{'类型': k, '数量': v} for k, v in type_data]
            fig_type = px.pie(df_type, values='数量', names='类型', title='按类型分布')
            st.plotly_chart(fig_type)
    
    with col2:
        if stats['by_subject']:
            # 使用索引方式创建DataFrame，避免类型错误
            subject_data = list(stats['by_subject'].items())
            df_subject = [{'学科': k, '数量': v} for k, v in subject_data]
            fig_subject = px.bar(df_subject, x='学科', y='数量', title='按学科分布')
            st.plotly_chart(fig_subject)
    
    # 导出功能
    st.markdown("### 💾 导出资源")
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("📥 导出所有资源"):
            try:
                filepath = st.session_state.generator.save_all_resources()
                st.success(f"资源已导出到: {filepath}")
                log_action(st.session_state.db, st.session_state['username'], 
                           "导出所有资源", st.session_state['is_admin'])
            except Exception as e:
                st.error(f"导出失败: {str(e)}")
    
    with col2:
        uploaded_file = st.file_uploader("导入资源文件", type=['json'])
        if uploaded_file and st.button("📤 导入资源"):
            try:
                filepath = os.path.join(Config.TEMP_DIR, uploaded_file.name)
                with open(filepath, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                
                resources = st.session_state.generator.load_resources(filepath)
                st.success(f"成功导入 {len(resources)} 个资源")
                log_action(st.session_state.db, st.session_state['username'], 
                           f"导入 {len(resources)} 个资源", st.session_state['is_admin'])
            except Exception as e:
                st.error(f"导入失败: {str(e)}")

def show_profile_page():
    """个人中心页面"""
    st.markdown("## 👤 个人中心")
    
    # 用户信息显示
    st.markdown(f"### 您好，{st.session_state['username']} {'(管理员)' if st.session_state['is_admin'] else ''}")
    
    # 创建标签页
    tab1, tab2, tab3 = st.tabs(["个人信息", "密码修改", "我的资源统计"])
    
    with tab1:
        st.markdown("#### 个人账户信息")
        
        # 获取当前用户信息
        if st.session_state['is_admin']:
            user_info = st.session_state.db.get_admin(st.session_state['username'])
        else:
            user_info = st.session_state.db.get_user(st.session_state['username'])
        
        if user_info:
            uid, username, password, created_at = user_info
            st.write(f"**用户名**: {username}")
            st.write(f"**账户类型**: {'管理员' if st.session_state['is_admin'] else '普通用户'}")
            st.write(f"**注册时间**: {created_at[:19]}")
            
            try:
                # 显示用户创建的资源数量
                user_resources = st.session_state.db.get_user_resources_count(username)
                st.write(f"**创建的资源数**: {user_resources}")
            except Exception as e:
                st.write(f"**创建的资源数**: 0")
    
    with tab2:
        st.markdown("#### 修改密码")
        
        with st.form("change_password_form"):
            current_password = st.text_input("当前密码", type="password")
            new_password = st.text_input("新密码", type="password")
            confirm_password = st.text_input("确认新密码", type="password")
            
            submitted = st.form_submit_button("修改密码")
            
            if submitted:
                if not current_password or not new_password or not confirm_password:
                    st.error("请填写所有密码字段")
                elif new_password != confirm_password:
                    st.error("新密码与确认密码不匹配")
                else:
                    # 验证当前密码
                    if st.session_state['is_admin']:
                        user_info = st.session_state.db.get_admin(st.session_state['username'])
                    else:
                        user_info = st.session_state.db.get_user(st.session_state['username'])
                    
                    if user_info and user_info[2] == current_password:
                        # 更新密码
                        if st.session_state['is_admin']:
                            st.session_state.db.reset_admin_password(st.session_state['username'], new_password)
                        else:
                            st.session_state.db.reset_user_password(st.session_state['username'], new_password)
                        
                        try:
                            log_action(st.session_state.db, st.session_state['username'], 
                                       "修改密码", st.session_state['is_admin'])
                        except Exception as e:
                            pass  # 忽略日志错误
                        st.success("密码修改成功！")
                    else:
                        st.error("当前密码不正确")
    
    with tab3:
        st.markdown("#### 我的资源统计")
        
        try:
            # 获取用户的资源
            user_resources = st.session_state.db.get_user_resources(st.session_state['username'])
            
            if user_resources:
                # 按类型统计
                type_stats = {}
                for r in user_resources:
                    t = r.get('type', 'unknown')
                    type_stats[t] = type_stats.get(t, 0) + 1
                
                # 创建饼图
                type_data = list(type_stats.items())
                df_type = [{'类型': k, '数量': v} for k, v in type_data]
                fig_type = px.pie(df_type, values='数量', names='类型', title='我的资源类型分布')
                st.plotly_chart(fig_type)
                
                # 显示最近创建的资源
                st.markdown("#### 最近创建的资源")
                for i, resource in enumerate(user_resources[:5]):
                    with st.expander(f"{resource['type']} - {resource.get('topic', '未知主题')}"):
                        st.write(f"创建时间: {resource['created_at']}")
                        render_content_with_math(resource['content'])
                        # 添加删除按钮
                        if st.button("🗑️ 删除此资源", key=f"del_profile_{i}_{resource['id']}"):
                            st.session_state.db.delete_resource(resource['id'])
                            log_action(st.session_state.db, st.session_state['username'], 
                                      f"从个人中心删除资源: {resource.get('topic', '未命名')}", 
                                      st.session_state['is_admin'])
                            st.success("资源已删除")
                            st.rerun()
            else:
                st.info("您还没有创建任何资源")
        except Exception as e:
            st.info("暂无资源统计数据")

def show_settings_page():
    """系统设置页面"""
    st.markdown("## ⚙️ 系统设置")
    
    # API配置
    st.markdown("### 🔑 API配置")
    api_key = st.text_input(
        "DeepSeek API密钥",
        value=Config.DEEPSEEK_API_KEY,
        type="password",
        help="请在config.py中设置DEEPSEEK_API_KEY"
    )
    
    if st.button("✅ 验证API"):
        try:
            Config.validate_config()
            st.success("API配置验证成功！")
        except Exception as e:
            st.error(f"API配置验证失败: {str(e)}")
    
    # 系统信息
    st.markdown("### ℹ️ 系统信息")
    st.write(f"**输出目录**: {Config.OUTPUT_DIR}")
    st.write(f"**临时目录**: {Config.TEMP_DIR}")
    st.write(f"**最大文件大小**: {Config.MAX_FILE_SIZE / (1024*1024):.1f} MB")
    
    # 支持的文件格式
    st.markdown("### 📁 支持的文件格式")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.write("**图像格式**:")
        for fmt in Config.SUPPORTED_IMAGE_FORMATS:
            st.write(f"  - {fmt}")
    
    with col2:
        st.write("**音频格式**:")
        for fmt in Config.SUPPORTED_AUDIO_FORMATS:
            st.write(f"  - {fmt}")
    
    with col3:
        st.write("**视频格式**:")
        for fmt in Config.SUPPORTED_VIDEO_FORMATS:
            st.write(f"  - {fmt}")

    # 管理员专属：用户与管理员管理
    if st.session_state.get('is_admin', False):
        st.markdown("---")
        st.markdown("### 👤 用户与管理员管理（仅管理员可见）")
        tabs = st.tabs(["用户管理", "管理员管理", "系统日志", "资源统计"])
        with tabs[0]:
            st.markdown("#### 所有用户")
            users = st.session_state.db.get_all_users()
            for user in users:
                uid, username, password, created_at = user
                col1, col2, col3, col4 = st.columns([3,2,2,2])
                col1.write(f"用户名：{username}")
                col2.write(f"注册时间：{created_at[:19]}")
                new_pwd = col3.text_input(f"新密码_{username}", value="", label_visibility="collapsed", placeholder="重置密码")
                if col3.button(f"重置密码", key=f"reset_{username}"):
                    if new_pwd:
                        st.session_state.db.reset_user_password(username, new_pwd)
                        try:
                            log_action(st.session_state.db, st.session_state['username'], 
                                       f"重置用户 {username} 的密码", True)
                        except Exception as e:
                            pass  # 忽略日志错误
                        st.success(f"{username} 密码已重置！")
                    else:
                        st.warning("请输入新密码")
                if col4.button(f"删除用户", key=f"deluser_{username}"):
                    st.session_state.db.delete_user(username)
                    try:
                        log_action(st.session_state.db, st.session_state['username'], 
                                   f"删除用户 {username}", True)
                    except Exception as e:
                        pass  # 忽略日志错误
                    st.success(f"{username} 已删除！")
                    st.rerun()
                
                # 显示用户的资源统计
                try:
                    user_resources_count = st.session_state.db.get_user_resources_count(username)
                    st.write(f"创建的资源数量: {user_resources_count}")
                except Exception as e:
                    st.write(f"创建的资源数量: 0")
                st.markdown("<hr style='margin: 0.5rem 0; opacity: 0.3;'>", unsafe_allow_html=True)
        with tabs[1]:
            st.markdown("#### 所有管理员")
            admins = st.session_state.db.get_all_admins()
            for admin in admins:
                aid, adminname, password, created_at = admin
                col1, col2, col3 = st.columns([4,3,2])
                col1.write(f"管理员名：{adminname}")
                col2.write(f"注册时间：{created_at[:19]}")
                if adminname != st.session_state['username']:
                    if col3.button(f"删除管理员", key=f"deladmin_{adminname}"):
                        st.session_state.db.delete_admin(adminname)
                        log_action(st.session_state.db, st.session_state['username'], 
                                   f"删除管理员 {adminname}", True)
                        st.success(f"{adminname} 已删除！")
                        st.rerun()
                else:
                    col3.write("当前登录")
                st.markdown("<hr style='margin: 0.5rem 0; opacity: 0.3;'>", unsafe_allow_html=True)
        
        with tabs[2]:
            st.markdown("#### 系统操作日志")
            try:
                logs = st.session_state.db.get_all_logs()
                
                # 日志管理功能
                st.markdown("##### 日志管理")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button("🗑️ 清空所有日志", key="clear_all_logs"):
                        st.session_state.db.delete_all_logs()
                        log_action(st.session_state.db, st.session_state['username'], 
                                   "清空所有系统日志", True)
                        st.success("所有日志已清空")
                        st.rerun()
                
                with col2:
                    days = st.number_input("保留天数", min_value=1, max_value=365, value=30)
                    if st.button("删除旧日志", key="clear_old_logs"):
                        # 计算要保留的日期
                        from datetime import timedelta
                        keep_date = (datetime.now() - timedelta(days=days)).isoformat()
                        st.session_state.db.delete_logs_before_date(keep_date)
                        log_action(st.session_state.db, st.session_state['username'], 
                                   f"删除 {days} 天前的系统日志", True)
                        st.success(f"已删除 {days} 天前的日志")
                        st.rerun()
                
                st.markdown("<hr/>", unsafe_allow_html=True)
                
                # 日期筛选
                st.markdown("##### 日志筛选")
                col1, col2 = st.columns(2)
                with col1:
                    start_date = st.date_input("开始日期")
                with col2:
                    end_date = st.date_input("结束日期")
                
                # 用户筛选
                all_usernames = list(set([log[1] for log in logs]))
                selected_users = st.multiselect("筛选用户", ["全部"] + all_usernames, default=["全部"])
                
                if st.button("筛选日志"):
                    filtered_logs = []
                    for log in logs:
                        log_id, username, action, timestamp, user_type = log
                        log_date = datetime.fromisoformat(timestamp).date()
                        
                        # 日期过滤
                        if log_date < start_date or log_date > end_date:
                            continue
                        
                        # 用户过滤
                        if "全部" not in selected_users and username not in selected_users:
                            continue
                        
                        filtered_logs.append(log)
                    
                    logs = filtered_logs
                
                # 显示日志
                st.markdown("##### 日志记录")
                st.markdown(f"共 {len(logs)} 条日志记录")
                
                for log in logs:
                    log_id, username, action, timestamp, user_type = log
                    col1, col2 = st.columns([5, 1])
                    
                    with col1:
                        st.markdown(f"**{timestamp[:19]}** - {username} ({user_type}): {action}")
                    
                    with col2:
                        if st.button("删除", key=f"del_log_{log_id}"):
                            st.session_state.db.delete_log(log_id)
                            log_action(st.session_state.db, st.session_state['username'], 
                                      f"删除日志ID: {log_id}", True)
                            st.success("日志已删除")
                            st.rerun()
                
            except Exception as e:
                st.info("暂无系统日志数据")
        
        with tabs[3]:
            st.markdown("#### 资源统计分析")
            
            try:
                # 获取所有资源
                all_resources = st.session_state.db.get_all_resources()
                
                # 按用户统计资源数量
                user_stats = {}
                for r in all_resources:
                    username = r.get('username', '未知用户')
                    user_stats[username] = user_stats.get(username, 0) + 1
                
                # 创建用户资源数量条形图
                user_data = list(user_stats.items())
                df_user = [{'用户': k, '资源数量': v} for k, v in user_data]
                if df_user:
                    fig_user = px.bar(df_user, x='用户', y='资源数量', title='各用户资源创建统计')
                    st.plotly_chart(fig_user)
                else:
                    st.info("暂无用户资源数据")
                
                # 按时间统计资源创建趋势
                date_stats = {}
                for r in all_resources:
                    date_str = r.get('created_at', '')[:10]  # 取日期部分
                    date_stats[date_str] = date_stats.get(date_str, 0) + 1
                
                # 创建时间趋势线图
                date_data = list(date_stats.items())
                date_data.sort(key=lambda x: x[0])  # 按日期排序
                df_date = [{'日期': k, '资源数量': v} for k, v in date_data]
                if df_date:
                    fig_date = px.line(df_date, x='日期', y='资源数量', title='资源创建时间趋势')
                    st.plotly_chart(fig_date)
                else:
                    st.info("暂无时间趋势数据")
            except Exception as e:
                st.info("暂无资源统计数据")

def display_resource(resource):
    """显示资源内容"""
    st.markdown("### 📄 生成结果")
    
    # 资源信息
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.write(f"**类型**: {resource['type']}")
        st.write(f"**ID**: {resource['id']}")
    
    with col2:
        if 'subject' in resource:
            st.write(f"**学科**: {resource['subject']}")
        if 'topic' in resource:
            st.write(f"**主题**: {resource['topic']}")
    
    with col3:
        st.write(f"**创建时间**: {resource['created_at']}")
        st.write(f"**标签**: {', '.join(resource['tags'])}")
    
    # 内容显示（简单渲染）
    st.markdown("### 📝 内容")
    render_content_with_math(resource['content'])
    
    # 自动保存到数据库
    save_resource_to_db(resource)
    
    # 操作按钮
    with st.expander("💾 导出/保存内容", expanded=False):
        col1, col2, col4 = st.columns(3)
        formatted = format_content_for_plaintext(resource['content'])
        nowstr = datetime.now().strftime('%Y%m%d_%H%M%S')
        base_name = f"{resource['type']}_{nowstr}"
        title = f"{resource.get('type', '')} - {resource.get('topic', '')}"
        
        with col1:
            if st.button("导出为TXT"):
                filename = save_content_as_txt(formatted, base_name)
                st.success(f"已导出为TXT: {filename}")
        with col2:
            if st.button("导出为Word"):
                filename = f"{Config.OUTPUT_DIR}/{base_name}.docx"
                save_content_as_word(formatted, filename, title=title)
                st.success(f"已导出为Word: {filename}")
        with col4:
            if st.button("复制纯文本"):
                st.code(formatted, language="text")
                st.success("内容已格式化为纯文本，可复制到剪贴板")
    
    # 重新生成按钮
    if st.button("🔄 重新生成"):
        st.session_state.current_resource = None
        st.rerun()

def save_content_as_txt(content, filename):
    import uuid
    import os
    from config import Config
    ext = filename.split('.')[-1]
    filename = os.path.join(Config.OUTPUT_DIR, f"{uuid.uuid4()}.{ext}")
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    return filename

if __name__ == "__main__":
    try:
        Config.validate_config()
        main()
    except Exception as e:
        st.error(f"系统初始化失败: {str(e)}")

# 添加网页底部版权声明
st.markdown("""
---
<div style='text-align:center; color: #888; font-size: 16px; margin-top: 40px;'>
本网站所有权归南京信息工程大学物联网安全与隐私保护课题组————AI_FBI小组所有
</div>
""", unsafe_allow_html=True) 
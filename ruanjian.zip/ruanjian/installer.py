import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox
import sys
import uuid

# 复制文件夹，排除venv/__pycache__等
EXCLUDE_DIRS = ['venv', '__pycache__', '.idea', 'output', 'temp']
EXCLUDE_FILES = ['installer.py', 'installer.bat']

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# 获取桌面路径
def get_desktop():
    return os.path.join(os.path.expanduser('~'), 'Desktop')

# 复制整个项目到目标目录
def copy_project(dst_dir):
    for root, dirs, files in os.walk(PROJECT_ROOT):
        rel_dir = os.path.relpath(root, PROJECT_ROOT)
        if any(x in rel_dir for x in EXCLUDE_DIRS):
            continue
        for file in files:
            if file in EXCLUDE_FILES:
                continue
            src_file = os.path.join(root, file)
            rel_file = os.path.relpath(src_file, PROJECT_ROOT)
            dst_file = os.path.join(dst_dir, rel_file)
            os.makedirs(os.path.dirname(dst_file), exist_ok=True)
            shutil.copy2(src_file, dst_file)

# 创建Windows桌面快捷方式
def create_shortcut(target, name):
    try:
        import pythoncom
        from win32com.shell import shell, shellcon
        from win32com.client import Dispatch
        desktop = get_desktop()
        shortcut_path = os.path.join(desktop, name + '.lnk')
        shortcut = Dispatch('WScript.Shell').CreateShortCut(shortcut_path)
        shortcut.Targetpath = target
        shortcut.WorkingDirectory = os.path.dirname(target)
        # 设置logo.jpg为图标（需ico格式）
        ico_path = os.path.join(PROJECT_ROOT, 'logo.ico')
        jpg_path = os.path.join(PROJECT_ROOT, 'logo.jpg')
        if not os.path.exists(ico_path) and os.path.exists(jpg_path):
            # 自动生成ico
            try:
                from PIL import Image
                img = Image.open(jpg_path)
                img = img.convert('RGBA')
                img.save(ico_path, format='ICO', sizes=[(64,64)])
            except Exception as e:
                print('自动生成ico失败:', e)
        if os.path.exists(ico_path):
            shortcut.IconLocation = ico_path
        shortcut.save()
    except Exception as e:
        print('创建快捷方式失败:', e)

def check_pywin32():
    try:
        import pythoncom
        from win32com.client import Dispatch
        return True
    except ImportError:
        tk.Tk().withdraw()
        messagebox.showerror('依赖缺失', '未检测到pywin32依赖，无法创建桌面快捷方式。\n请先运行：pip install pywin32')
        return False

# 安装主流程
def do_install():
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo('安装', '请选择安装目录')
    install_dir = filedialog.askdirectory(title='选择安装目录')
    if not install_dir:
        messagebox.showwarning('安装', '未选择目录，已取消安装')
        return
    # 生成唯一子目录防止覆盖
    install_dir = os.path.join(install_dir, f'YouYuBao_{uuid.uuid4().hex[:8]}')
    os.makedirs(install_dir, exist_ok=True)
    copy_project(install_dir)
    # 判断是否有simple_start.exe，否则用simple_start.py
    exe_path = os.path.join(install_dir, 'simple_start.exe')
    if not os.path.exists(exe_path):
        exe_path = os.path.join(install_dir, 'simple_start.py')
    if check_pywin32():
        create_shortcut(exe_path, 'YouYuBao教学资源系统')
        messagebox.showinfo('安装完成', f'已安装到: {install_dir}\n桌面已创建快捷方式')
    else:
        messagebox.showinfo('安装完成', f'已安装到: {install_dir}\n(未创建桌面快捷方式，请先安装pywin32)')

if __name__ == '__main__':
    do_install() 
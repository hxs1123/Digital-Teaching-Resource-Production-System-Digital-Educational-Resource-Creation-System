class Config:
    """系统配置类"""
    
    # 直接写死API密钥
    DEEPSEEK_API_KEY = "sk-ddcdb1747ff14061bb857c78aa5181f4"
    DEEPSEEK_API_BASE = "https://api.deepseek.com"
    
    # 系统配置
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    SUPPORTED_IMAGE_FORMATS = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']
    SUPPORTED_AUDIO_FORMATS = ['.mp3', '.wav', '.flac', '.m4a', '.aac']
    SUPPORTED_VIDEO_FORMATS = ['.mp4', '.avi', '.mov', '.mkv', '.wmv']
    
    # 模型配置
    DEFAULT_MODEL = "deepseek-chat"
    VISION_MODEL = "deepseek-vision"
    
    # 输出配置
    OUTPUT_DIR = "output"
    TEMP_DIR = "temp"
    
    # UI配置
    PAGE_TITLE = "YouYuBao教学资源制作系统"
    PAGE_ICON = "🎓"
    
    @classmethod
    def validate_config(cls):
        """验证配置是否完整"""
        if not cls.DEEPSEEK_API_KEY:
            raise ValueError("请在config.py中设置DEEPSEEK_API_KEY")
        
        # 创建必要的目录
        import os
        os.makedirs(cls.OUTPUT_DIR, exist_ok=True)
        os.makedirs(cls.TEMP_DIR, exist_ok=True) 

        # 支持API Key等敏感信息通过环境变量读取
        DEEPSEEK_API_KEY = os.environ.get('DEEPSEEK_API_KEY', getattr(Config, 'DEEPSEEK_API_KEY', '')) 
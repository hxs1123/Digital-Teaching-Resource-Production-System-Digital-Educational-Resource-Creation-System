import requests
import json
import base64
import mimetypes
from typing import List, Dict, Any, Optional
from config import Config
import datetime
import os
from PIL import Image

class DeepSeekClient:
    """DeepSeek API客户端"""
    
    def __init__(self):
        self.api_key = Config.DEEPSEEK_API_KEY
        self.api_base = Config.DEEPSEEK_API_BASE
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
    
    def _encode_image(self, image_path: str) -> str:
        """将图片编码为base64"""
        with open(image_path, 'rb') as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    
    def chat_completion(self, messages: List[Dict], model: str = None) -> Dict:
        """文本对话完成"""
        if model is None:
            model = Config.DEFAULT_MODEL
            
        url = f"{self.api_base}/v1/chat/completions"
        data = {
            "model": model,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 2000
        }
        
        try:
            response = requests.post(url, headers=self.headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"API请求失败: {str(e)}")
    
    def vision_completion(self, messages: List[Dict], model: str = None) -> Dict:
        """多模态对话完成（支持图像）"""
        if model is None:
            model = Config.VISION_MODEL
            
        url = f"{self.api_base}/v1/chat/completions"
        data = {
            "model": model,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 2000
        }
        
        try:
            response = requests.post(url, headers=self.headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"API请求失败: {str(e)}")
    
    def generate_teaching_content(self, subject: str, topic: str, grade_level: str, 
                                content_type: str = "lesson_plan") -> str:
        """生成教学内容"""
        prompt = f"""
        请为{grade_level}学生生成关于"{topic}"的{content_type}。
        学科：{subject}
        
        请提供详细、结构化的内容，包括：
        1. 教学目标
        2. 教学内容
        3. 教学方法
        4. 评估方式
        5. 相关活动建议
        
        请用中文回答，内容要适合{grade_level}学生的认知水平。
        """
        
        messages = [
            {"role": "user", "content": prompt}
        ]
        
        response = self.chat_completion(messages)
        return response['choices'][0]['message']['content']
    
    def analyze_image(self, image_path: str, analysis_type: str = "general") -> str:
        """分析图像内容"""
        # 编码图像
        base64_image = self._encode_image(image_path)
        
        if analysis_type == "educational":
            prompt = "请分析这张图片的教育价值，包括：1. 适合的学科和年级 2. 可以讨论的话题 3. 教学建议"
        else:
            prompt = "请详细描述这张图片的内容，包括主要元素、场景、颜色等特征。"
        
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}"
                        }
                    }
                ]
            }
        ]
        
        # 强制使用多模态模型
        response = self.vision_completion(messages, model=Config.VISION_MODEL)
        return response['choices'][0]['message']['content']
    
    def create_quiz(self, topic: str, subject: str, difficulty: str = "medium", 
                   question_count: int = 5) -> str:
        """创建测验题目"""
        prompt = f"""
        请为{topic}主题创建{question_count}道测验题目。
        学科：{subject}
        难度：{difficulty}
        
        请提供：
        1. 多种题型（选择题、填空题、简答题等）
        2. 每道题的答案和解析
        3. 适合的年级水平
        
        请用中文回答。
        """
        
        messages = [
            {"role": "user", "content": prompt}
        ]
        
        response = self.chat_completion(messages)
        return response['choices'][0]['message']['content']
    
    def generate_learning_activities(self, topic: str, subject: str, 
                                   activity_type: str = "interactive") -> str:
        """生成学习活动"""
        prompt = f"""
        请为{topic}主题设计学习活动。
        学科：{subject}
        活动类型：{activity_type}
        
        请提供：
        1. 活动目标
        2. 活动步骤
        3. 所需材料
        4. 时间安排
        5. 评估方式
        
        请用中文回答。
        """
        
        messages = [
            {"role": "user", "content": prompt}
        ]
        
        response = self.chat_completion(messages)
        return response['choices'][0]['message']['content'] 

class DoubaoClient:
    """豆包API客户端，兼容DeepSeekClient接口"""
    def __init__(self):
        self.api_key = "388a04a3-aebd-45e4-b54e-5c86c246d3e5"  # 你的豆包API Key
        self.api_base = "https://ark.cn-beijing.volces.com/api/v3"
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        self.model = "doubao-seed-1-6-flash-250715"

    def _encode_image(self, image_path: str) -> str:
        """将图片转换为RGB标准格式后编码为base64，并返回正确的data:image/xxx;base64,前缀"""
        mime_type, _ = mimetypes.guess_type(image_path)
        if mime_type is None:
            mime_type = 'image/jpeg'  # 默认兜底
        # 自动转换为RGB标准格式
        temp_path = image_path
        try:
            with Image.open(image_path) as img:
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                    temp_path = image_path + '_rgb_temp.jpg'
                    img.save(temp_path, format='JPEG')
                    mime_type = 'image/jpeg'
        except Exception as e:
            pass  # 打开失败则按原图处理
        with open(temp_path, 'rb') as image_file:
            base64_data = base64.b64encode(image_file.read()).decode('utf-8')
        # 清理临时文件
        if temp_path != image_path and os.path.exists(temp_path):
            os.remove(temp_path)
        return f"data:{mime_type};base64,{base64_data}"

    def chat_completion(self, messages: list, model: str = None) -> dict:
        """文本对话完成（兼容接口）"""
        if model is None:
            model = self.model
        url = f"{self.api_base}/chat/completions"
        data = {
            "model": model,
            "messages": messages
        }
        try:
            response = requests.post(url, headers=self.headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            if hasattr(e, 'response') and e.response is not None:
                print('豆包API详细报错:', e.response.text)
            raise Exception(f"豆包API请求失败: {str(e)}")

    def vision_completion(self, messages: list, model: str = None) -> dict:
        """多模态对话完成（支持图像，兼容接口）"""
        if model is None:
            model = self.model
        url = f"{self.api_base}/chat/completions"
        data = {
            "model": model,
            "messages": messages
        }
        try:
            response = requests.post(url, headers=self.headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            if hasattr(e, 'response') and e.response is not None:
                print('豆包API详细报错:', e.response.text)
            raise Exception(f"豆包API请求失败: {str(e)}") 

    def analyze_image(self, image_path: str, analysis_type: str = "general") -> str:
        """分析图像内容，兼容DeepSeekClient接口"""
        base64_image = self._encode_image(image_path)
        if analysis_type == "educational":
            prompt = "请分析这张图片的教育价值，包括：1. 适合的学科和年级 2. 可以讨论的话题 3. 教学建议"
        else:
            prompt = "请详细描述这张图片的内容，包括主要元素、场景、颜色等特征。"
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": base64_image
                        }
                    }
                ]
            }
        ]
        response = self.vision_completion(messages)
        return response['choices'][0]['message']['content'] 

    def generate_teaching_content(self, subject: str, topic: str, grade_level: str, content_type: str = "lesson_plan") -> str:
        prompt = f"""
        请为{grade_level}学生生成关于"{topic}"的{content_type}。
        学科：{subject}

        请提供详细、结构化的内容，包括：
        1. 教学目标
        2. 教学内容
        3. 教学方法
        4. 评估方式
        5. 相关活动建议

        请用中文回答，内容要适合{grade_level}学生的认知水平。
        """
        messages = [
            {"role": "user", "content": prompt}
        ]
        response = self.chat_completion(messages)
        return response['choices'][0]['message']['content'] 

    def generate_learning_activities(self, topic: str, subject: str, activity_type: str = "interactive") -> str:
        prompt = f"""
        请为{topic}主题设计学习活动。
        学科：{subject}
        活动类型：{activity_type}

        请提供：
        1. 活动目标
        2. 活动步骤
        3. 所需材料
        4. 时间安排
        5. 评估方式

        请用中文回答。
        """
        messages = [
            {"role": "user", "content": prompt}
        ]
        response = self.chat_completion(messages)
        return response['choices'][0]['message']['content'] 

    def create_quiz(self, topic: str, subject: str, difficulty: str = "medium", question_count: int = 5) -> str:
        prompt = f"""
        请为{topic}主题创建{question_count}道测验题目。
        学科：{subject}
        难度：{difficulty}

        请提供：
        1. 多种题型（选择题、填空题、简答题等）
        2. 每道题的答案和解析
        3. 适合的年级水平

        请用中文回答。
        """
        messages = [
            {"role": "user", "content": prompt}
        ]
        response = self.chat_completion(messages)
        return response['choices'][0]['message']['content'] 
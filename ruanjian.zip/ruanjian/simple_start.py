#!/usr/bin/env python3
"""
简化的启动脚本 - 直接启动数字化教学资源制作系统

用法说明：
- 默认使用DeepSeek API。
- 如需切换为豆包API，请在resource_generator初始化时传入use_doubao=True。
  例如：generator = TeachingResourceGenerator(use_doubao=True)

"""

import subprocess
import sys
import os
from resource_generator import TeachingResourceGenerator

def main():
    """主函数"""
    print("🎓 YouYuBao教学资源制作系统")
    print("=" * 50)
    print("🚀 正在启动应用...")
    print("访问地址: http://localhost:8501")
    print("按Ctrl+C停止应用")
    print()
    
    try:
        # 直接启动Streamlit应用
        subprocess.run([
            sys.executable, '-m', 'streamlit', 'run', 'app.py',
            '--server.port', '8501',
            '--server.address', 'localhost'
        ])
    except KeyboardInterrupt:
        print("\n👋 应用已停止")
    except Exception as e:
        print(f"❌ 应用启动失败: {e}")
        print("请确保已安装所需依赖包:")
        print("pip install streamlit requests pillow python-dotenv")


if __name__ == '__main__':
    main()
import os
import json
import hashlib
from datetime import datetime
from typing import List, Dict, Any
from config import Config

def validate_file_type(filename: str, allowed_types: List[str]) -> bool:
    """验证文件类型"""
    file_ext = os.path.splitext(filename)[1].lower()
    return file_ext in allowed_types

def validate_file_size(file_path: str, max_size: int) -> bool:
    """验证文件大小"""
    if not os.path.exists(file_path):
        return False
    
    file_size = os.path.getsize(file_path)
    return file_size <= max_size

def generate_file_hash(file_path: str) -> str:
    """生成文件哈希值"""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def sanitize_filename(filename: str) -> str:
    """清理文件名"""
    # 移除或替换不安全的字符
    unsafe_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
    for char in unsafe_chars:
        filename = filename.replace(char, '_')
    return filename

def format_file_size(size_bytes: int) -> str:
    """格式化文件大小"""
    if size_bytes == 0:
        return "0B"
    
    size_names = ["B", "KB", "MB", "GB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f}{size_names[i]}"

def create_backup(data: Any, backup_dir: str = "backups") -> str:
    """创建数据备份"""
    os.makedirs(backup_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"backup_{timestamp}.json"
    filepath = os.path.join(backup_dir, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    return filepath

def load_backup(backup_file: str) -> Any:
    """加载备份数据"""
    with open(backup_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def get_file_info(file_path: str) -> Dict[str, Any]:
    """获取文件信息"""
    if not os.path.exists(file_path):
        return {}
    
    stat = os.stat(file_path)
    return {
        "name": os.path.basename(file_path),
        "size": stat.st_size,
        "size_formatted": format_file_size(stat.st_size),
        "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
        "hash": generate_file_hash(file_path)
    }

def cleanup_temp_files(temp_dir: str = None, max_age_hours: int = 24):
    """清理临时文件"""
    if temp_dir is None:
        temp_dir = Config.TEMP_DIR
    
    if not os.path.exists(temp_dir):
        return
    
    current_time = datetime.now()
    for filename in os.listdir(temp_dir):
        file_path = os.path.join(temp_dir, filename)
        
        if os.path.isfile(file_path):
            file_time = datetime.fromtimestamp(os.path.getctime(file_path))
            age_hours = (current_time - file_time).total_seconds() / 3600
            
            if age_hours > max_age_hours:
                try:
                    os.remove(file_path)
                except Exception as e:
                    print(f"删除临时文件失败: {file_path}, 错误: {e}")

def validate_api_response(response: Dict) -> bool:
    """验证API响应"""
    if not isinstance(response, dict):
        return False
    
    if 'choices' not in response:
        return False
    
    if not response['choices']:
        return False
    
    choice = response['choices'][0]
    if 'message' not in choice:
        return False
    
    if 'content' not in choice['message']:
        return False
    
    return True

def extract_content_from_response(response: Dict) -> str:
    """从API响应中提取内容"""
    if not validate_api_response(response):
        return ""
    
    return response['choices'][0]['message']['content']

def format_timestamp(timestamp: str) -> str:
    """格式化时间戳"""
    try:
        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except:
        return timestamp

def truncate_text(text: str, max_length: int = 200) -> str:
    """截断文本"""
    if len(text) <= max_length:
        return text
    
    return text[:max_length] + "..."

def create_resource_summary(resource: Dict) -> Dict[str, Any]:
    """创建资源摘要"""
    return {
        "id": resource.get("id", ""),
        "type": resource.get("type", ""),
        "subject": resource.get("subject", ""),
        "topic": resource.get("topic", ""),
        "created_at": format_timestamp(resource.get("created_at", "")),
        "content_preview": truncate_text(resource.get("content", ""), 150),
        "tags": resource.get("tags", [])
    }

def search_in_content(content: str, query: str) -> bool:
    """在内容中搜索关键词"""
    if not query:
        return True
    
    return query.lower() in content.lower()

def filter_resources_by_tags(resources: List[Dict], tags: List[str]) -> List[Dict]:
    """按标签筛选资源"""
    if not tags:
        return resources
    
    filtered = []
    for resource in resources:
        resource_tags = resource.get('tags', [])
        if any(tag in resource_tags for tag in tags):
            filtered.append(resource)
    
    return filtered

def sort_resources_by_date(resources: List[Dict], reverse: bool = True) -> List[Dict]:
    """按日期排序资源"""
    return sorted(
        resources,
        key=lambda x: x.get('created_at', ''),
        reverse=reverse
    )

def get_resource_statistics_summary(stats: Dict) -> Dict[str, Any]:
    """获取资源统计摘要"""
    return {
        "total": stats.get('total_resources', 0),
        "by_type": stats.get('by_type', {}),
        "by_subject": stats.get('by_subject', {}),
        "by_grade": stats.get('by_grade', {}),
        "recent_count": len(stats.get('recent_resources', []))
    } 
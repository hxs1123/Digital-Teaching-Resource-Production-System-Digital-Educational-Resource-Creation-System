#!/usr/bin/env python3
"""
依赖包安装脚本
"""

import subprocess
import sys

def install_dependencies():
    """安装依赖包"""
    print("📦 正在安装依赖包...")
    
    # 需要安装的包
    packages = [
        'streamlit==1.28.1',
        'requests==2.31.0',
        'pillow==10.0.1',
        'python-dotenv==1.0.0',
        'plotly==5.17.0'
    ]
    
    for package in packages:
        print(f"正在安装 {package}...")
        try:
            subprocess.check_call([
                sys.executable, '-m', 'pip', 'install', package
            ])
            print(f"✅ {package} 安装成功")
        except subprocess.CalledProcessError as e:
            print(f"❌ {package} 安装失败: {e}")
            return False
    
    print("\n🎉 所有依赖包安装完成！")
    return True

def main():
    """主函数"""
    print("🎓 YouYuBao教学资源制作系统 - 依赖安装")
    print("=" * 50)
    
    if install_dependencies():
        print("\n✅ 安装完成！现在可以运行应用了:")
        print("   python simple_start.py")
        print("   或双击 simple_start.bat")
    else:
        print("\n❌ 安装失败，请检查网络连接或手动安装")

if __name__ == '__main__':
    main() 
import sqlite3
import json
from datetime import datetime
import bcrypt

DB_PATH = 'resource_data.db'

class ResourceDB:
    def __init__(self, db_path=DB_PATH):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.create_table()
        self.migrate_database()  # 添加数据库迁移检查

    def create_table(self):
        sql = '''CREATE TABLE IF NOT EXISTS resources (
            id TEXT PRIMARY KEY,
            type TEXT,
            subject TEXT,
            topic TEXT,
            grade_level TEXT,
            content TEXT,
            created_at TEXT,
            tags TEXT
        )'''
        self.conn.execute(sql)
        # 新增用户表
        sql_user = '''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            created_at TEXT
        )'''
        self.conn.execute(sql_user)
        # 新增管理员表
        sql_admin = '''CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            created_at TEXT
        )'''
        self.conn.execute(sql_admin)
        self.conn.commit()
    
    def migrate_database(self):
        """数据库迁移：检查并添加缺失的列"""
        try:
            # 检查resources表是否有username列
            cursor = self.conn.execute("SELECT username FROM resources LIMIT 1")
            cursor.fetchone()  # 尝试获取一行数据
        except sqlite3.OperationalError:
            # 如果没有username列，添加它
            print("正在迁移数据库：添加username列...")
            self.conn.execute("ALTER TABLE resources ADD COLUMN username TEXT")
            self.conn.commit()
            print("数据库迁移完成。")
        
        # 创建日志表
        self.create_log_table()
        
    def create_log_table(self):
        """创建系统日志表"""
        sql_log = '''CREATE TABLE IF NOT EXISTS system_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            action TEXT,
            timestamp TEXT,
            user_type TEXT
        )'''
        self.conn.execute(sql_log)
        self.conn.commit()

    def save_resource(self, resource):
        """保存资源，兼容新旧数据库结构"""
        try:
            # 尝试使用新结构（包含username）
            sql = '''REPLACE INTO resources (id, type, subject, topic, grade_level, content, created_at, tags, username)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'''
            tags = json.dumps(resource.get('tags', []), ensure_ascii=False)
            self.conn.execute(sql, (
                resource.get('id'),
                resource.get('type'),
                resource.get('subject'),
                resource.get('topic'),
                resource.get('grade_level'),
                resource.get('content'),
                resource.get('created_at'),
                tags,
                resource.get('username', '')
            ))
        except sqlite3.OperationalError:
            # 如果失败，尝试使用旧结构（不包含username）
            sql = '''REPLACE INTO resources (id, type, subject, topic, grade_level, content, created_at, tags)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'''
            tags = json.dumps(resource.get('tags', []), ensure_ascii=False)
            self.conn.execute(sql, (
                resource.get('id'),
                resource.get('type'),
                resource.get('subject'),
                resource.get('topic'),
                resource.get('grade_level'),
                resource.get('content'),
                resource.get('created_at'),
                tags
            ))
            # 然后尝试迁移数据库
            self.migrate_database()
        
        self.conn.commit()

    def get_all_resources(self):
        sql = 'SELECT * FROM resources ORDER BY created_at DESC'
        cur = self.conn.execute(sql)
        rows = cur.fetchall()
        return [self.row_to_dict(row) for row in rows]

    def get_resource_by_id(self, rid):
        sql = 'SELECT * FROM resources WHERE id=?'
        cur = self.conn.execute(sql, (rid,))
        row = cur.fetchone()
        return self.row_to_dict(row) if row else None

    def search_resources(self, query='', tags=None):
        sql = 'SELECT * FROM resources WHERE 1=1'
        params = []
        if query:
            sql += ' AND (content LIKE ? OR topic LIKE ? OR subject LIKE ? OR grade_level LIKE ? OR type LIKE ?)' 
            q = f'%{query}%'
            params += [q, q, q, q, q]
        if tags:
            for tag in tags:
                sql += ' AND tags LIKE ?'
                params.append(f'%{tag}%')
        sql += ' ORDER BY created_at DESC'
        cur = self.conn.execute(sql, params)
        rows = cur.fetchall()
        return [self.row_to_dict(row) for row in rows]
        
    def search_user_resources(self, username, query='', tags=None):
        """搜索特定用户的资源"""
        sql = 'SELECT * FROM resources WHERE username=?'
        params = [username]
        if query:
            sql += ' AND (content LIKE ? OR topic LIKE ? OR subject LIKE ? OR grade_level LIKE ? OR type LIKE ?)' 
            q = f'%{query}%'
            params += [q, q, q, q, q]
        if tags:
            for tag in tags:
                sql += ' AND tags LIKE ?'
                params.append(f'%{tag}%')
        sql += ' ORDER BY created_at DESC'
        cur = self.conn.execute(sql, params)
        rows = cur.fetchall()
        return [self.row_to_dict(row) for row in rows]
        
    def get_user_resources(self, username):
        """获取特定用户的所有资源"""
        sql = 'SELECT * FROM resources WHERE username=? ORDER BY created_at DESC'
        cur = self.conn.execute(sql, (username,))
        rows = cur.fetchall()
        return [self.row_to_dict(row) for row in rows]
        
    def get_user_resources_count(self, username):
        """获取特定用户的资源数量"""
        sql = 'SELECT COUNT(*) FROM resources WHERE username=?'
        cur = self.conn.execute(sql, (username,))
        return cur.fetchone()[0]
        
    def delete_resource(self, resource_id):
        """删除指定ID的资源"""
        sql = 'DELETE FROM resources WHERE id=?'
        self.conn.execute(sql, (resource_id,))
        self.conn.commit()

    def row_to_dict(self, row):
        if not row:
            return None
        result = {
            'id': row[0],
            'type': row[1],
            'subject': row[2],
            'topic': row[3],
            'grade_level': row[4],
            'content': row[5],
            'created_at': row[6],
            'tags': json.loads(row[7]) if row[7] else []
        }
        
        # 检查是否有username列
        if len(row) > 8:
            result['username'] = row[8]
        else:
            result['username'] = ''
            
        return result

    def close(self):
        self.conn.close()

    # 用户相关
    def add_user(self, username, password):
        # 密码加密存储
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        sql = 'INSERT INTO users (username, password, created_at) VALUES (?, ?, ?)' 
        self.conn.execute(sql, (username, hashed, datetime.now().isoformat()))
        self.conn.commit()

    def get_user(self, username):
        sql = 'SELECT * FROM users WHERE username=?'
        cur = self.conn.execute(sql, (username,))
        return cur.fetchone()

    def get_all_users(self):
        sql = 'SELECT * FROM users ORDER BY created_at DESC'
        cur = self.conn.execute(sql)
        return cur.fetchall()

    def delete_user(self, username):
        sql = 'DELETE FROM users WHERE username=?'
        self.conn.execute(sql, (username,))
        self.conn.commit()

    def reset_user_password(self, username, new_password):
        # 密码加密存储
        hashed = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        sql = 'UPDATE users SET password=? WHERE username=?'
        self.conn.execute(sql, (hashed, username))
        self.conn.commit()

    # 管理员相关
    def add_admin(self, username, password):
        # 密码加密存储
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        sql = 'INSERT INTO admins (username, password, created_at) VALUES (?, ?, ?)' 
        self.conn.execute(sql, (username, hashed, datetime.now().isoformat()))
        self.conn.commit()

    def get_admin(self, username):
        sql = 'SELECT * FROM admins WHERE username=?'
        cur = self.conn.execute(sql, (username,))
        return cur.fetchone()

    def get_all_admins(self):
        sql = 'SELECT * FROM admins ORDER BY created_at DESC'
        cur = self.conn.execute(sql)
        return cur.fetchall()

    def delete_admin(self, username):
        sql = 'DELETE FROM admins WHERE username=?'
        self.conn.execute(sql, (username,))
        self.conn.commit() 
        
    def reset_admin_password(self, username, new_password):
        # 密码加密存储
        hashed = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        sql = 'UPDATE admins SET password=? WHERE username=?'
        self.conn.execute(sql, (hashed, username))
        self.conn.commit()
        
    # 系统日志相关
    def add_log(self, username, action, user_type):
        """添加系统操作日志"""
        try:
            sql = 'INSERT INTO system_logs (username, action, timestamp, user_type) VALUES (?, ?, ?, ?)'
            self.conn.execute(sql, (username, action, datetime.now().isoformat(), user_type))
            self.conn.commit()
        except sqlite3.OperationalError:
            # 如果表不存在，先创建
            self.create_log_table()
            self.add_log(username, action, user_type)
            
    def get_all_logs(self):
        """获取所有系统日志"""
        try:
            sql = 'SELECT * FROM system_logs ORDER BY timestamp DESC'
            cur = self.conn.execute(sql)
            return cur.fetchall()
        except sqlite3.OperationalError:
            # 如果表不存在，先创建
            self.create_log_table()
            return []
            
    def delete_log(self, log_id):
        """删除指定ID的日志"""
        sql = 'DELETE FROM system_logs WHERE id=?'
        self.conn.execute(sql, (log_id,))
        self.conn.commit()
        
    def delete_all_logs(self):
        """删除所有系统日志"""
        sql = 'DELETE FROM system_logs'
        self.conn.execute(sql)
        self.conn.commit()
        
    def delete_logs_before_date(self, date_str):
        """删除指定日期之前的所有日志"""
        sql = 'DELETE FROM system_logs WHERE timestamp < ?'
        self.conn.execute(sql, (date_str,))
        self.conn.commit() 
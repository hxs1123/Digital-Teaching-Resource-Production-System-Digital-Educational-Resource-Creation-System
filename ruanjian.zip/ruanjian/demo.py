#!/usr/bin/env python3
"""
YouYuBao教学资源制作系统演示脚本
"""

import os
import sys
from config import Config
from resource_generator import TeachingResourceGenerator

def print_banner():
    """打印系统横幅"""
    print("🎓" + "="*50 + "🎓")
    print("    YouYuBao教学资源制作系统演示")
    print("🎓" + "="*50 + "🎓")
    print()

def check_environment():
    """检查运行环境"""
    print("🔍 检查运行环境...")
    
    # 检查Python版本
    if sys.version_info < (3, 8):
        print("❌ 错误: 需要Python 3.8或更高版本")
        return False
    
    print(f"✅ Python版本: {sys.version.split()[0]}")
    
    # 检查必要的目录
    os.makedirs(Config.OUTPUT_DIR, exist_ok=True)
    os.makedirs(Config.TEMP_DIR, exist_ok=True)
    print(f"✅ 输出目录: {Config.OUTPUT_DIR}")
    print(f"✅ 临时目录: {Config.TEMP_DIR}")
    
    # 检查API配置
    if not Config.DEEPSEEK_API_KEY:
        print("⚠️  警告: 未配置DeepSeek API密钥")
        print("   请在.env文件中设置DEEPSEEK_API_KEY")
        return False
    
    print("✅ API配置检查通过")
    return True

def demo_lesson_plan_generation():
    """演示教案生成功能"""
    print("\n📝 演示教案生成功能...")
    
    try:
        generator = TeachingResourceGenerator()
        
        # 生成教案
        resource = generator.generate_lesson_plan(
            subject="数学",
            topic="二次函数",
            grade_level="高中一年级"
        )
        
        print("✅ 教案生成成功！")
        print(f"   主题: {resource['topic']}")
        print(f"   学科: {resource['subject']}")
        print(f"   年级: {resource['grade_level']}")
        print(f"   内容长度: {len(resource['content'])} 字符")
        
        # 保存资源
        filepath = generator.save_resource(resource)
        print(f"   保存路径: {filepath}")
        
        return True
        
    except Exception as e:
        print(f"❌ 教案生成失败: {e}")
        return False

def demo_quiz_generation():
    """演示测验生成功能"""
    print("\n❓ 演示测验生成功能...")
    
    try:
        generator = TeachingResourceGenerator()
        
        # 生成测验
        resource = generator.generate_quiz(
            topic="三角函数",
            subject="数学",
            difficulty="medium",
            question_count=3
        )
        
        print("✅ 测验生成成功！")
        print(f"   主题: {resource['topic']}")
        print(f"   难度: {resource['difficulty']}")
        print(f"   题目数量: {resource['question_count']}")
        print(f"   内容长度: {len(resource['content'])} 字符")
        
        # 保存资源
        filepath = generator.save_resource(resource)
        print(f"   保存路径: {filepath}")
        
        return True
        
    except Exception as e:
        print(f"❌ 测验生成失败: {e}")
        return False

def demo_activity_generation():
    """演示活动设计功能"""
    print("\n🎯 演示活动设计功能...")
    
    try:
        generator = TeachingResourceGenerator()
        
        # 生成活动
        resource = generator.generate_activities(
            topic="科学实验",
            subject="物理",
            activity_type="experiment"
        )
        
        print("✅ 活动设计成功！")
        print(f"   主题: {resource['topic']}")
        print(f"   活动类型: {resource['activity_type']}")
        print(f"   内容长度: {len(resource['content'])} 字符")
        
        # 保存资源
        filepath = generator.save_resource(resource)
        print(f"   保存路径: {filepath}")
        
        return True
        
    except Exception as e:
        print(f"❌ 活动设计失败: {e}")
        return False

def demo_resource_management():
    """演示资源管理功能"""
    print("\n📊 演示资源管理功能...")
    
    try:
        generator = TeachingResourceGenerator()
        
        # 获取统计信息
        stats = generator.get_resource_statistics()
        
        print("✅ 资源统计信息:")
        print(f"   总资源数: {stats['total_resources']}")
        print(f"   按类型分布: {stats['by_type']}")
        print(f"   按学科分布: {stats['by_subject']}")
        
        # 搜索功能演示
        if stats['total_resources'] > 0:
            results = generator.search_resources('数学')
            print(f"   搜索'数学'相关资源: {len(results)} 个")
        
        return True
        
    except Exception as e:
        print(f"❌ 资源管理演示失败: {e}")
        return False

def show_usage_instructions():
    """显示使用说明"""
    print("\n📖 使用说明:")
    print("1. 启动Web界面: python run.py")
    print("2. 或直接运行: streamlit run app.py")
    print("3. 访问地址: http://localhost:8501")
    print()
    print("🔧 主要功能:")
    print("   - 📝 智能教案生成")
    print("   - ❓ 测验题目创建")
    print("   - 🎯 学习活动设计")
    print("   - 🖼️ 图像内容分析")
    print("   - 🔍 多模态内容生成")
    print("   - 📊 资源管理系统")
    print()

def main():
    """主函数"""
    print_banner()
    
    # 检查环境
    if not check_environment():
        print("\n❌ 环境检查失败，请检查配置后重试")
        return 1
    
    print("\n🚀 开始功能演示...")
    
    # 演示各项功能
    demos = [
        ("教案生成", demo_lesson_plan_generation),
        ("测验生成", demo_quiz_generation),
        ("活动设计", demo_activity_generation),
        ("资源管理", demo_resource_management)
    ]
    
    success_count = 0
    total_count = len(demos)
    
    for name, demo_func in demos:
        try:
            if demo_func():
                success_count += 1
        except Exception as e:
            print(f"❌ {name}演示异常: {e}")
    
    # 显示结果
    print(f"\n📈 演示结果: {success_count}/{total_count} 项功能演示成功")
    
    if success_count == total_count:
        print("🎉 所有功能演示成功！系统运行正常。")
    else:
        print("⚠️  部分功能演示失败，请检查API配置和网络连接。")
    
    # 显示使用说明
    show_usage_instructions()
    
    return 0 if success_count == total_count else 1

if __name__ == '__main__':
    exit(main()) 
#!/bin/bash

echo "🎓 数字化教学资源制作系统"
echo "================================================"
echo "🚀 正在启动应用..."
echo "访问地址: http://localhost:8501"
echo "按Ctrl+C停止应用"
echo ""
streamlit run app.py 
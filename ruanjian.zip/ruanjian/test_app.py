import unittest
import os
import json
import tempfile
from unittest.mock import Mock, patch
from config import Config
from deepseek_client import DeepSeekClient
from resource_generator import TeachingResourceGenerator
from utils import validate_file_type, validate_file_size, format_file_size

class TestConfig(unittest.TestCase):
    """测试配置类"""
    
    def test_config_validation(self):
        """测试配置验证"""
        # 测试API密钥为空的情况
        with patch.dict(os.environ, {'DEEPSEEK_API_KEY': ''}):
            with self.assertRaises(ValueError):
                Config.validate_config()
    
    def test_supported_formats(self):
        """测试支持的文件格式"""
        self.assertIn('.jpg', Config.SUPPORTED_IMAGE_FORMATS)
        self.assertIn('.mp3', Config.SUPPORTED_AUDIO_FORMATS)
        self.assertIn('.mp4', Config.SUPPORTED_VIDEO_FORMATS)

class TestDeepSeekClient(unittest.TestCase):
    """测试DeepSeek客户端"""
    
    def setUp(self):
        """设置测试环境"""
        self.client = DeepSeekClient()
    
    @patch('requests.post')
    def test_chat_completion(self, mock_post):
        """测试文本对话完成"""
        # 模拟API响应
        mock_response = Mock()
        mock_response.json.return_value = {
            'choices': [{'message': {'content': '测试回复'}}]
        }
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        messages = [{'role': 'user', 'content': '测试消息'}]
        result = self.client.chat_completion(messages)
        
        self.assertEqual(result['choices'][0]['message']['content'], '测试回复')
    
    def test_encode_image(self):
        """测试图像编码"""
        # 创建临时图像文件
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as f:
            f.write(b'fake_image_data')
            temp_image_path = f.name
        
        try:
            encoded = self.client._encode_image(temp_image_path)
            self.assertIsInstance(encoded, str)
            self.assertTrue(len(encoded) > 0)
        finally:
            os.unlink(temp_image_path)

class TestResourceGenerator(unittest.TestCase):
    """测试资源生成器"""
    
    def setUp(self):
        """设置测试环境"""
        # 确保输出目录存在
        os.makedirs(Config.OUTPUT_DIR, exist_ok=True)
        os.makedirs(Config.TEMP_DIR, exist_ok=True)
        
        self.generator = TeachingResourceGenerator()
        # 清空资源列表，确保每个测试都是独立的
        self.generator.resources = []
    
    def tearDown(self):
        """清理测试环境"""
        # 清空资源列表
        self.generator.resources = []
    
    @patch.object(DeepSeekClient, 'generate_teaching_content')
    def test_generate_lesson_plan(self, mock_generate):
        """测试教案生成"""
        mock_generate.return_value = "测试教案内容"
        
        resource = self.generator.generate_lesson_plan(
            subject="数学",
            topic="二次函数",
            grade_level="高中一年级"
        )
        
        self.assertEqual(resource['type'], 'lesson_plan')
        self.assertEqual(resource['subject'], '数学')
        self.assertEqual(resource['topic'], '二次函数')
        self.assertEqual(resource['content'], '测试教案内容')
    
    @patch.object(DeepSeekClient, 'create_quiz')
    def test_generate_quiz(self, mock_create):
        """测试测验生成"""
        mock_create.return_value = "测试测验内容"
        
        resource = self.generator.generate_quiz(
            topic="三角函数",
            subject="数学",
            difficulty="medium",
            question_count=5
        )
        
        self.assertEqual(resource['type'], 'quiz')
        self.assertEqual(resource['difficulty'], 'medium')
        self.assertEqual(resource['question_count'], 5)
    
    def test_save_and_load_resources(self):
        """测试资源保存和加载"""
        # 创建测试资源
        test_resource = {
            'id': 'test_123',
            'type': 'test',
            'content': '测试内容'
        }
        
        # 保存资源
        filepath = self.generator.save_resource(test_resource, 'test.json')
        self.assertTrue(os.path.exists(filepath))
        
        # 创建新的生成器实例来测试加载
        new_generator = TeachingResourceGenerator()
        new_generator.resources = []  # 确保是空的
        
        # 加载资源
        loaded_resources = new_generator.load_resources(filepath)
        self.assertEqual(len(loaded_resources), 1)
        self.assertEqual(loaded_resources[0]['id'], 'test_123')
        
        # 清理测试文件
        os.unlink(filepath)
    
    def test_search_resources(self):
        """测试资源搜索"""
        # 添加测试资源
        test_resources = [
            {
                'id': 'test1',
                'type': 'lesson_plan',
                'subject': '数学',
                'topic': '二次函数',
                'content': '二次函数教学内容',
                'tags': ['数学', '二次函数', '教案']
            },
            {
                'id': 'test2',
                'type': 'quiz',
                'subject': '语文',
                'topic': '古诗文',
                'content': '古诗文测验',
                'tags': ['语文', '古诗文', '测验']
            }
        ]
        
        self.generator.resources = test_resources
        
        # 测试关键词搜索
        results = self.generator.search_resources('二次函数')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], 'test1')
        
        # 测试标签搜索
        results = self.generator.search_resources('', tags=['测验'])
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], 'test2')

class TestUtils(unittest.TestCase):
    """测试工具函数"""
    
    def test_validate_file_type(self):
        """测试文件类型验证"""
        self.assertTrue(validate_file_type('test.jpg', ['.jpg', '.png']))
        self.assertFalse(validate_file_type('test.txt', ['.jpg', '.png']))
    
    def test_validate_file_size(self):
        """测试文件大小验证"""
        # 创建临时文件
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b'x' * 100)  # 100字节
            temp_file_path = f.name
        
        try:
            self.assertTrue(validate_file_size(temp_file_path, 200))
            self.assertFalse(validate_file_size(temp_file_path, 50))
        finally:
            os.unlink(temp_file_path)
    
    def test_format_file_size(self):
        """测试文件大小格式化"""
        self.assertEqual(format_file_size(1024), '1.0KB')
        self.assertEqual(format_file_size(1024*1024), '1.0MB')
        self.assertEqual(format_file_size(0), '0B')

class TestIntegration(unittest.TestCase):
    """集成测试"""
    
    def setUp(self):
        """设置测试环境"""
        # 创建临时目录
        self.temp_dir = tempfile.mkdtemp()
        self.original_output_dir = Config.OUTPUT_DIR
        self.original_temp_dir = Config.TEMP_DIR
        Config.OUTPUT_DIR = os.path.join(self.temp_dir, 'output')
        Config.TEMP_DIR = os.path.join(self.temp_dir, 'temp')
        
        # 创建目录
        os.makedirs(Config.OUTPUT_DIR, exist_ok=True)
        os.makedirs(Config.TEMP_DIR, exist_ok=True)
    
    def tearDown(self):
        """清理测试环境"""
        import shutil
        shutil.rmtree(self.temp_dir)
        Config.OUTPUT_DIR = self.original_output_dir
        Config.TEMP_DIR = self.original_temp_dir
    
    @patch.object(DeepSeekClient, 'generate_teaching_content')
    def test_full_workflow(self, mock_generate):
        """测试完整工作流程"""
        mock_generate.return_value = "完整的教案内容"
        
        generator = TeachingResourceGenerator()
        generator.resources = []  # 确保是空的
        
        # 生成资源
        resource = generator.generate_lesson_plan(
            subject="数学",
            topic="微积分",
            grade_level="高中三年级"
        )
        
        # 验证资源
        self.assertIsNotNone(resource)
        self.assertEqual(resource['type'], 'lesson_plan')
        
        # 保存资源
        filepath = generator.save_resource(resource)
        self.assertTrue(os.path.exists(filepath))
        
        # 验证保存的内容
        with open(filepath, 'r', encoding='utf-8') as f:
            saved_data = json.load(f)
        
        self.assertEqual(saved_data['id'], resource['id'])
        self.assertEqual(saved_data['content'], resource['content'])

def run_tests():
    """运行所有测试"""
    # 创建测试套件
    test_suite = unittest.TestSuite()
    
    # 添加测试类
    test_classes = [
        TestConfig,
        TestDeepSeekClient,
        TestResourceGenerator,
        TestUtils,
        TestIntegration
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    return result.wasSuccessful()

if __name__ == '__main__':
    print("开始运行测试...")
    success = run_tests()
    
    if success:
        print("\n✅ 所有测试通过！")
    else:
        print("\n❌ 部分测试失败！")
    
    exit(0 if success else 1) 